package com.gemini.guard

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import io.github.muntashirakon.adb.android.AndroidUtils
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Tro nang CHI de doc ma ghep doi 6 so + IP:cong tren hop thoai "Ghep noi thiet bi bang ma".
 * Quet MOI cua so (khong chi cua so dang co tieu diem, vi o nhap noi cua app co the chiem tieu diem)
 * va khong gioi han ten goi (OriginOS co the dung goi khac com.android.settings).
 * Chi hanh dong khi cung mot cua so co ca ma 6 so lan IP:cong; khong luu / khong gui ma di dau;
 * tu tat sau khi ghep doi xong.
 */
class PairWatcher : AccessibilityService() {
    private val busy = AtomicBoolean(false)
    @Volatile private var lastKey = ""
    @Volatile private var lastTs = 0L
    @Volatile private var lastDiag = 0L
    private val codeRe = Regex("^(\\d{3})\\s?(\\d{3})$")
    private val hostRe = Regex("(\\d{1,3}(?:\\.\\d{1,3}){3}):(\\d{2,5})")

    private class Hit { var code: String? = null; var host: String? = null; var port = -1; var texts = 0 }

    override fun onServiceConnected() {
        super.onServiceConnected()
        AdbSelf.log(L.tr("Trợ năng tự nhận mã đã bật."))
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        AdbSelf.log(L.tr("Trợ năng tự nhận mã đã tắt."))
        return super.onUnbind(intent)
    }

    // Bat moi loi de dich vu khong bao gio lam sap tien trinh.
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try { handle() } catch (t: Throwable) {
            try { AdbSelf.log(L.tr("Lỗi Trợ năng: ") + t) } catch (_: Throwable) {}
        }
    }

    private fun scan(n: AccessibilityNodeInfo?, depth: Int, h: Hit) {
        if (n == null || depth > 40) return
        val t = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
        if (t.isNotEmpty()) {
            h.texts++
            if (h.code == null) {
                val m = codeRe.matchEntire(t)
                if (m != null) h.code = m.groupValues[1] + m.groupValues[2]
            }
            if (h.host == null) {
                val m = hostRe.find(t)
                if (m != null) { h.host = m.groupValues[1]; h.port = m.groupValues[2].toInt() }
            }
        }
        for (i in 0 until n.childCount) scan(n.getChild(i), depth + 1, h)
    }

    private fun diag(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastDiag < 4000) return
        lastDiag = now
        AdbSelf.log(msg)
    }

    private fun handle() {
        val roots = ArrayList<AccessibilityNodeInfo>()
        try { windows?.forEach { w -> w.root?.let { roots.add(it) } } } catch (_: Throwable) {}
        if (roots.isEmpty()) rootInActiveWindow?.let { roots.add(it) }
        val seen = StringBuilder()
        for (root in roots) {
            val pkg = root.packageName?.toString() ?: "?"
            if (pkg == packageName) continue   // bo qua o nhap noi cua chinh app
            val h = Hit()
            scan(root, 0, h)
            seen.append(pkg).append('(').append(h.texts).append(") ")
            val cd = h.code ?: continue
            var host = h.host
            var port = h.port
            // Khong thay IP:cong trong hop thoai -> dung cong do mDNS (chi voi cua so cua app Cai dat)
            if (host == null && AdbSelf.lastPort > 0 && pkg.contains("settings", ignoreCase = true)) {
                host = AndroidUtils.getHostIpAddress(applicationContext)
                port = AdbSelf.lastPort
            }
            if (host == null || port <= 0) {
                diag(L.tr("Thấy mã 6 số nhưng chưa thấy cổng ghép đôi."))
                continue
            }
            startPair(cd, host, port)
            return
        }
        if (AdbSelf.armed()) diag(L.tr("Trợ năng thấy cửa sổ: ") + seen.toString().trim())
    }

    private fun startPair(cd: String, host: String, port: Int) {
        val key = "$cd@$host:$port"
        val now = System.currentTimeMillis()
        if (key == lastKey && now - lastTs < 8000) return
        if (!busy.compareAndSet(false, true)) return
        lastKey = key
        lastTs = now
        AdbSelf.log(L.tr("Đã đọc mã ghép đôi từ Cài đặt, đang ghép đôi…"))
        val app = applicationContext
        Thread {
            try {
                val res = AdbSelf.pair(app, host, port, cd)
                AdbSelf.notifyResult(app, res)
                if (AdbSelf.linked) {
                    AdbSelf.log(L.tr("Đã ghép đôi, tự tắt Trợ năng."))
                    try { disableSelf() } catch (_: Throwable) {}
                }
            } finally {
                busy.set(false)
            }
        }.start()
    }

    override fun onInterrupt() {}
}
