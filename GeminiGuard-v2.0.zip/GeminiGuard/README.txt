GEMINI GUARD 4.0
- Upload zip nay len GitHub (cung ten GeminiGuard-v2.0.zip de ghi de, repo chi nen co 1 file zip). Actions tu build APK.
- Cai APK DE LEN ban cu (khong go app) de giu quyen ADB.
- Cap quyen 1 lan: pm grant com.gemini.guard android.permission.WRITE_SECURE_SETTINGS
- Phim tat Tro nang: o "Tro nang Gemini Guard" trong Control Center (muc Phim nhanh ung dung),
  hoac nhan giu icon app -> "Bat/tat Tro nang".

- v3.7: tich hop Shizuku. Bat Shizuku, mo app, bam "Tu cap quyen qua Shizuku" thay cho lenh adb tren may tinh.
- v3.8: ADB tich hop (khong can app Shizuku): ghep noi 1 lan qua Go loi khong day, nhap ma trong thong bao.
- v3.9: man hinh Shizuku day du: tu doc ma ghep doi bang Tro nang (PairWatcher), thong bao, ngat ket noi, tien trinh.
