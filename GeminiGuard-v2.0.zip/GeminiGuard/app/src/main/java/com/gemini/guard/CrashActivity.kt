package com.gemini.guard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Hien noi dung loi khi app bi van (chay o tien trinh rieng ":crash" nen van mo duoc khi tien trinh chinh chet). */
class CrashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val text = intent.getStringExtra("t") ?: "(không có nội dung)"
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0E14.toInt())
            setPadding(dp(16), dp(44), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            this.text = "AloGemini bị lỗi"; textSize = 20f; setTextColor(0xFFD4AF37.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            this.text = "Chụp màn hình này gửi cho người hỗ trợ, hoặc bấm Sao chép."
            textSize = 13f; setTextColor(0xFF9CA3AF.toInt())
        })
        val tv = TextView(this).apply {
            this.text = text; textSize = 10f; typeface = Typeface.MONOSPACE; setTextColor(0xFFF3F4F6.toInt())
            setTextIsSelectable(true)
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(ScrollView(this).apply { addView(tv) }, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val copy = Button(this).apply { this.text = "Sao chép"; isAllCaps = false }
        val close = Button(this).apply { this.text = "Đóng"; isAllCaps = false }
        row.addView(copy, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(close, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)
        setContentView(root)
        copy.setOnClickListener {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("crash", text))
            Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show()
        }
        close.setOnClickListener { finishAndRemoveTask() }
    }
}
