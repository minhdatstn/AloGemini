package com.gemini.guard

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings

/**
 * Tu tat dich vu Tro nang cua AloGemini khi mo mot app trong danh sach ngan hang/VNeID,
 * tu bat lai khi roi khoi app do. Dung UsageStatsManager (nhu NoAccWatcher) de biet app nao
 * dang o man hinh - khong dung Tro nang de theo doi, vi luc do Tro nang co the dang bi tat.
 *
 * Trang thai "dang tat vi ngan hang" luu vao SharedPreferences (key bank_disabled_by_us) thay
 * vi bien nho tam, de khong bi mat khi tien trinh GuardService bi he thong tat/khoi dong lai
 * giua luc nguoi dung van con trong app ngan hang.
 */
object BankGuard {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var app: Context? = null
    private var lastCheckTs = 0L

    fun svcComponent(c: Context): String = ComponentName(c, MiAiWatcher::class.java).flattenToString()

    /** So sanh theo ComponentName de nhan ra ca dang ten day du lan ten ngan (pkg/.Class). */
    private fun isOurs(c: Context, entry: String): Boolean =
        ComponentName.unflattenFromString(entry.trim()) == ComponentName(c, MiAiWatcher::class.java)

    private fun accessibilityOn(c: Context): Boolean {
        val cur = Settings.Secure.getString(c.contentResolver, Restorer.ACC_KEY) ?: ""
        return cur.split(":").any { isOurs(c, it) }
    }

    fun isAccessibilityOn(c: Context): Boolean = accessibilityOn(c)

    /** Bat/tat rieng dich vu AloGemini, giu nguyen moi dich vu Tro nang khac dang bat. */
    fun setAccessibility(c: Context, enable: Boolean): Boolean = try {
        val r = c.contentResolver
        val comp = svcComponent(c)
        val cur = (Settings.Secure.getString(r, Restorer.ACC_KEY) ?: "").split(":").filter { it.isNotBlank() }.toMutableList()
        val has = cur.any { isOurs(c, it) }
        if (enable && !has) cur.add(comp)
        if (!enable) cur.removeAll { isOurs(c, it) }
        Settings.Secure.putString(r, Restorer.ACC_KEY, cur.joinToString(":"))
        if (enable) Settings.Secure.putInt(r, "accessibility_enabled", 1)
        true
    } catch (_: Throwable) { false }

    /** Goi lai moi khi bat/tat cong tac hoac doi danh sach app, de bat/dung polling cho khop. */
    fun sync(c: Context) {
        app = c.applicationContext
        val pr = Restorer.prefs(c)
        val want = pr.getBoolean("bank_guard_on", false) && NoAccWatcher.hasUsageAccess(c) && Restorer.hasPermission(c)
        if (want && !running) {
            running = true
            lastCheckTs = System.currentTimeMillis() - 1000
            handler.removeCallbacks(loop)
            handler.post(loop)
        } else if (!want && running) {
            running = false
            handler.removeCallbacks(loop)
            reenableIfOurs(c)
        }
    }

    fun stop(c: Context) {
        running = false
        handler.removeCallbacks(loop)
        reenableIfOurs(c)
    }

    private fun reenableIfOurs(c: Context) {
        val pr = Restorer.prefs(c)
        if (pr.getBoolean("bank_disabled_by_us", false)) {
            if (setAccessibility(c, true)) pr.edit().putBoolean("bank_disabled_by_us", false).apply()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val c = app
            if (c != null) try { poll(c) } catch (_: Throwable) {}
            val ms = (c?.let { Restorer.prefs(it).getInt("bank_poll_ms", 500) } ?: 500).coerceIn(200, 2000)
            handler.postDelayed(this, ms.toLong())
        }
    }

    private fun poll(c: Context) {
        val now = System.currentTimeMillis()
        val from = lastCheckTs
        lastCheckTs = now
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return
        val pr = Restorer.prefs(c)
        val pkgs = (pr.getString("bank_pkgs", "") ?: "").split(",", ";", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        if (pkgs.isEmpty()) return
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        var lastFg: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                (Build.VERSION.SDK_INT >= 29 && e.eventType == UsageEvents.Event.ACTIVITY_RESUMED)) lastFg = e.packageName
        }
        if (lastFg == null) return   // khong co app nao doi sang trong khoang nay, khong can lam gi
        val disabledByUs = pr.getBoolean("bank_disabled_by_us", false)
        val nowInBank = lastFg in pkgs
        if (nowInBank && !disabledByUs) {
            if (accessibilityOn(c) && setAccessibility(c, false)) pr.edit().putBoolean("bank_disabled_by_us", true).apply()
        } else if (!nowInBank && disabledByUs) {
            if (setAccessibility(c, true)) pr.edit().putBoolean("bank_disabled_by_us", false).apply()
        }
    }
}
