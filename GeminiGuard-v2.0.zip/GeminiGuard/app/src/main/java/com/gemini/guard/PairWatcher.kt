package com.gemini.guard

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Tro nang CHI de doc ma ghep doi 6 so + IP:cong tren hop thoai "Ghep noi thiet bi bang ma" cua app Cai dat.
 * Chi hoat dong khi nguoi dung vua bam "Mo go loi khong day" trong app (armed), chi nhin app Cai dat,
 * khong luu / khong gui ma di dau, va tu tat sau khi ghep doi xong.
 */
class PairWatcher : AccessibilityService() {
    private val busy = AtomicBoolean(false)
    @Volatile private var lastKey = ""
    private val codeRe = Regex("^\\d{6}$")
    private val hostRe = Regex("(\\d{1,3}(?:\\.\\d{1,3}){3}):(\\d{2,5})")

    override fun onServiceConnected() {
        super.onServiceConnected()
        AdbSelf.log(L.tr("Trợ năng tự nhận mã đã bật."))
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        AdbSelf.log(L.tr("Trợ năng tự nhận mã đã tắt."))
        return super.onUnbind(intent)
    }

    // Bat moi loi de dich vu khong bao gio lam sap tien trinh (he thong se tu tat dich vu bi loi).
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try { handle(e) } catch (t: Throwable) {
            try { AdbSelf.log(L.tr("Lỗi Trợ năng: ") + t) } catch (_: Throwable) {}
        }
    }

    private fun handle(e: AccessibilityEvent?) {
        if (e == null || !AdbSelf.armed()) return
        if (e.packageName?.toString() != "com.android.settings") return
        val root = rootInActiveWindow ?: return
        var code: String? = null
        var host: String? = null
        var port = -1
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 30) return
            val t = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) {
                if (code == null && codeRe.matches(t)) code = t
                if (host == null) {
                    val m = hostRe.find(t)
                    if (m != null) { host = m.groupValues[1]; port = m.groupValues[2].toInt() }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        val cd = code
        val h = host
        val pt = port
        if (cd == null || h == null || pt <= 0) return
        val key = "$cd@$h:$pt"
        if (key == lastKey || !busy.compareAndSet(false, true)) return
        lastKey = key
        AdbSelf.log(L.tr("Đã đọc mã ghép đôi từ Cài đặt, đang ghép đôi…"))
        val app = applicationContext
        Thread {
            try {
                val res = AdbSelf.pair(app, h, pt, cd)
                AdbSelf.notifyResult(app, res)
                if (AdbSelf.linked) {
                    AdbSelf.log(L.tr("Đã ghép đôi, tự tắt Trợ năng."))
                    try { disableSelf() } catch (_: Throwable) {}
                }
            } finally {
                busy.set(false)
            }
        }.start()
    }

    override fun onInterrupt() {}
}
