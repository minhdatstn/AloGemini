package com.gemini.guard

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.widget.Toast

/**
 * MUC KIEM TRA: thu phat hien Jovi va goi Gemini MA KHONG bat dich vu Tro nang,
 * de app ngan hang / vi dien tu khong canh bao "rui ro mat tien" (cac app do quet
 * danh sach dich vu Tro nang dang bat, khong lien quan quyen "Truy cap su dung" o day).
 *
 * Cach hoat dong, khac han JoviWatcher:
 *  - Phat hien: dung UsageStatsManager (quyen "Truy cap su dung") de hoi dinh ky app nao
 *    vua len nen truoc, thay vi Tro nang bao cua so doi theo thoi gian thuc. Vi la hoi
 *    dinh ky nen luon CHAM hon mot chut so voi Tro nang; polling cang nhanh cang ton pin.
 *  - Dong Jovi: KHONG the bam Back hay cham man hinh nhu Tro nang (can quyen do). Chi co
 *    the thu dung tien trinh cua Jovi va gui broadcast dong dialog he thong. Ca hai deu
 *    KHONG chac chan dong duoc lop phu Jovi - day la ly do tinh nang nay can duoc TEST
 *    truoc khi dung that, va vi vay duoc dat rieng trong "Muc kiem tra".
 */
object NoAccWatcher {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var app: Context? = null
    private var lastCheckTs = 0L
    private var lastFire = 0L

    fun hasUsageAccess(c: Context): Boolean = try {
        val aom = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            aom.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else @Suppress("DEPRECATION") aom.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Throwable) { false }

    fun openUsageSettings(c: Context) {
        try { c.startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Throwable) { Toast.makeText(c, L.tr("Không mở được trang cài đặt"), Toast.LENGTH_LONG).show() }
    }

    /** Goi lai moi khi bat/tat cong tac hoac doi thong so, de bat/dung polling cho khop. */
    fun sync(c: Context) {
        app = c.applicationContext
        val pr = Restorer.prefs(c)
        val want = pr.getBoolean("noacc_on", false) && hasUsageAccess(c)
        if (want && !running) {
            running = true
            lastCheckTs = System.currentTimeMillis() - 1000
            handler.removeCallbacks(loop)
            handler.post(loop)
        } else if (!want && running) {
            running = false
            handler.removeCallbacks(loop)
        }
    }

    fun stop() {
        running = false
        handler.removeCallbacks(loop)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val c = app
            if (c != null) try { poll(c) } catch (_: Throwable) {}
            val ms = (c?.let { Restorer.prefs(it).getInt("noacc_poll_ms", 300) } ?: 300).coerceIn(100, 2000)
            handler.postDelayed(this, ms.toLong())
        }
    }

    private fun poll(c: Context) {
        val now = System.currentTimeMillis()
        val from = lastCheckTs
        lastCheckTs = now
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return
        val pr = Restorer.prefs(c)
        val pkgs = (pr.getString("jovi_pkgs", JoviWatcher.DEFAULT_PKGS) ?: JoviWatcher.DEFAULT_PKGS)
            .split(",", ";", " ", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        var hit: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            // Lop phu giong noi cua Jovi thuong KHONG mo mot Activity moi (khong co MOVE_TO_FOREGROUND/
            // ACTIVITY_RESUMED) ma chi chay nhu dich vu nen de ve lop phu, nen phai bat ca
            // FOREGROUND_SERVICE_START (API 28+) moi mong bat duoc kieu goi nay.
            val fg = e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                (Build.VERSION.SDK_INT >= 29 && e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) ||
                (Build.VERSION.SDK_INT >= 28 && e.eventType == UsageEvents.Event.FOREGROUND_SERVICE_START)
            if (fg && e.packageName in pkgs) hit = e.packageName
        }
        if (hit != null && now - lastFire > 4000) {
            lastFire = now
            fire(c, hit)
        }
    }

    /** Thu dong Jovi (khong chac chan) roi goi Gemini. Dung ca cho nut "Thu ngay". */
    fun fire(c: Context, pkg: String) {
        try { (c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).killBackgroundProcesses(pkg) } catch (_: Throwable) {}
        try { c.sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) } catch (_: Throwable) {}
        Restorer.ensure(c)
        val delay = Restorer.prefs(c).getInt("noacc_delay_ms", 150).coerceIn(0, 2000).toLong()
        handler.postDelayed({
            val err = GeminiCall.show()
            if (err == null) GeminiSound.play(c) else
                Toast.makeText(c, L.tr("Không gọi được Gemini: ") + err, Toast.LENGTH_LONG).show()
        }, delay)
    }

    /** Nut "Thu ngay" trong UI: gia lap nhu vua phat hien duoc Jovi, khong can cho that su bat len. */
    fun test(c: Context) {
        val pkg = (Restorer.prefs(c).getString("jovi_pkgs", JoviWatcher.DEFAULT_PKGS) ?: JoviWatcher.DEFAULT_PKGS)
            .split(",", ";", " ", "\n").map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: JoviWatcher.DEFAULT_PKGS
        fire(c, pkg)
    }
}
