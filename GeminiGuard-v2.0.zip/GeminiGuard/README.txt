ALO GEMINI 5.1 — thuần vivo OriginOS · by Dragon
- Đây là bản bỏ hết Xiaomi / HyperOS / Mi AI, đổi tên toàn diện thành AloGemini (tác giả: Dragon) và giao diện chia theo từng mục (Tab).
- Repo GitHub chỉ để 1 file zip tên GeminiGuard-v2.0.zip (xóa zip cũ rồi upload file này).
  Actions tự build APK.
- Cài APK ĐÈ LÊN bản cũ (không gỡ app) để giữ quyền ADB.
- Lần mở đầu tiên app tự xóa danh sách gói Mi AI cũ và chuyển sang Jovi / BlueLM.
- Nút nguồn: app giữ tắt công tắc vivo_jovi_power_wakeup_switch để giữ nút nguồn gọi Gemini.
- Nếu Jovi hoặc BlueLM vẫn bật lớp phủ (gọi "tiểu V", giữ nút nguồn), bật Trợ năng
  "AloGemini – theo dõi Jovi" để đóng lớp phủ đó rồi gọi Gemini.
- Tự khởi động: nút trong app mở iManager / Quản lý tự khởi động của vivo.
