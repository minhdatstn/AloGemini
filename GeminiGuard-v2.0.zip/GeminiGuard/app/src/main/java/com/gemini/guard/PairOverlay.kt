package com.gemini.guard

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * O nhap ma noi, hien tren man hinh Cai dat de nguoi dung go ma ghep doi ma KHONG roi khoi Cai dat
 * (hop thoai ghep noi se dong neu roi Cai dat). Khong phu thuoc thong bao hay Tro nang.
 * Can quyen "Hien thi tren ung dung khac".
 */
object PairOverlay {
    private val main = Handler(Looper.getMainLooper())
    private var view: View? = null

    fun shown(): Boolean = view != null

    fun show(c: Context) = main.post {
        try {
            if (view != null) return@post
            val app = c.applicationContext
            val wm = app.getSystemService(WindowManager::class.java)
            val d = app.resources.displayMetrics.density
            fun dp(v: Int) = (v * d).toInt()

            val box = LinearLayout(app).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = GradientDrawable().apply {
                    setColor(0xFF141824.toInt()); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0xFFD4AF37.toInt())
                }
            }
            box.addView(TextView(app).apply {
                text = L.tr("Nhập mã ghép đôi"); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFFF3F4F6.toInt())
            })
            box.addView(TextView(app).apply {
                text = L.tr("Gõ mã 6 số đang hiện trong hộp thoại. Nếu báo thiếu cổng, gõ cổng trước mã, ví dụ: 41234 123456")
                textSize = 12f; setTextColor(0xFF9CA3AF.toInt())
            })
            val et = EditText(app).apply {
                hint = L.tr("Mã 6 số (thêm cổng nếu cần)")
                inputType = InputType.TYPE_CLASS_TEXT
                setSingleLine(true)
                setTextColor(0xFFF3F4F6.toInt()); setHintTextColor(0xFF6B7280.toInt())
            }
            box.addView(et)
            val row = LinearLayout(app).apply { orientation = LinearLayout.HORIZONTAL }
            val ok = Button(app).apply { text = L.tr("Ghép đôi"); isAllCaps = false; setTextColor(0xFFD4AF37.toInt()) }
            val close = Button(app).apply { text = L.tr("Đóng"); isAllCaps = false; setTextColor(0xFF9CA3AF.toInt()) }
            row.addView(ok, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(close, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            box.addView(row)

            ok.setOnClickListener {
                val raw = et.text.toString()
                Toast.makeText(app, L.tr("Đang ghép đôi…"), Toast.LENGTH_SHORT).show()
                Thread {
                    val r = AdbSelf.pairFromInput(app, raw, AdbSelf.lastPort)
                    main.post {
                        Toast.makeText(app, r, Toast.LENGTH_LONG).show()
                        if (AdbSelf.linked) hide()
                    }
                }.start()
            }
            close.setOnClickListener { hide() }

            val lp = WindowManager.LayoutParams(
                (app.resources.displayMetrics.widthPixels * 0.92f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(90)
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
            }
            wm.addView(box, lp)
            view = box
            AdbSelf.log(L.tr("Đã hiện ô nhập mã nổi trên màn hình."))
        } catch (t: Throwable) {
            AdbSelf.log(L.tr("Không hiện được ô nhập nổi: ") + t.message)
        }
    }

    fun hide() = main.post {
        val v = view ?: return@post
        view = null
        try { v.context.getSystemService(WindowManager::class.java).removeView(v) } catch (_: Throwable) {}
    }
}
