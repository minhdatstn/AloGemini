package com.gemini.guard

import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Nhan ma ghep noi nguoi dung go trong thong bao roi ghep noi + ket noi. */
class PairReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = RemoteInput.getResultsFromIntent(i)?.getCharSequence(AdbSelf.KEY_CODE)?.toString()?.trim().orEmpty()
        val port = i.getIntExtra(AdbSelf.EXTRA_PORT, 0)
        if (code.isEmpty()) return
        val app = c.applicationContext
        val pr = goAsync()
        Thread {
            val res = try { AdbSelf.pairFromInput(app, code, port) } catch (e: Throwable) { L.tr("Lỗi ghép nối: ") + e.message }
            AdbSelf.notifyResult(app, res)
            pr.finish()
        }.start()
    }
}
