package com.gemini.guard

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast

class GuardService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bar: BarOverlay
    private var lastScreenToggleTs = 0L
    private var lastDtTriggerTs = 0L

    private val check = Runnable { Restorer.ensure(this) }
    private val periodic = object : Runnable {
        override fun run() {
            Restorer.ensure(this@GuardService)
            handler.postDelayed(this, 15 * 60 * 1000L)   // da co ContentObserver bat thay doi ngay, day chi la du phong
        }
    }
    private val prefListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "noacc_on" || key == "noacc_poll_ms") NoAccWatcher.sync(this@GuardService)
        if (key == "bank_guard_on" || key == "bank_pkgs" || key == "bank_poll_ms") BankGuard.sync(this@GuardService)
    }
    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) {
            // Cho OriginOS ghi xong roi moi ghi de
            handler.removeCallbacks(check)
            handler.postDelayed(check, 1500)
        }
    }

    /**
     * Phat hien Nhan dup nut nguon qua chuoi tat -> bat man hinh (ACTION_SCREEN_OFF / ACTION_SCREEN_ON).
     * Android khong gui KEYCODE_POWER cho AccessibilityService, nhung luon phat broadcast tat/bat man hinh
     * khi nguoi dung bam nut nguon 2 lan lien tiep.
     */
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val act = intent?.action ?: return
            if (act != Intent.ACTION_SCREEN_OFF && act != Intent.ACTION_SCREEN_ON) return
            val pr = Restorer.prefs(this@GuardService)
            val dtChoice = pr.getString("pwr_dt", "none") ?: "none"
            if (dtChoice == "none") return

            val now = SystemClock.elapsedRealtime()
            val windowMs = pr.getInt("pwr_dt_ms", 650).coerceIn(300, 1500).toLong()
            val delta = now - lastScreenToggleTs
            lastScreenToggleTs = now

            if (delta in 80..windowMs && now - lastDtTriggerTs > 2000L) {
                lastDtTriggerTs = now
                lastScreenToggleTs = 0L
                triggerDoublePressPower(dtChoice)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun triggerDoublePressPower(choice: String) {
        try {
            val pm = getSystemService(PowerManager::class.java)
            val wl = pm?.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                "AloGemini:DoublePressWake"
            )
            wl?.acquire(3000L)
        } catch (_: Throwable) {}

        Haptic.pop(this, force = true)
        // Doi 250ms de man hinh sang han roi moi goi Gemini / Circle to Search
        handler.postDelayed({
            when (choice) {
                "gemini" -> {
                    Restorer.ensure(this)
                    val err = Restorer.callTarget(this)
                    if (err == null) GeminiSound.play(this)
                    else Toast.makeText(this, L.fmt("Không gọi được %s: %s", Restorer.targetLabel(this), err), Toast.LENGTH_LONG).show()
                }
                "micts" -> {
                    val pkg = Restorer.prefs(this).getString("cts_pkg", "com.parallelc.micts") ?: "com.parallelc.micts"
                    val i = packageManager.getLaunchIntentForPackage(pkg)
                    if (i == null) {
                        Toast.makeText(this, L.fmt("Chưa cài Circle to Search (%s)", pkg), Toast.LENGTH_LONG).show()
                    } else {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try { startActivity(i) } catch (e: Exception) {
                            Toast.makeText(this, L.tr("Lỗi mở Circle to Search: ") + e.message, Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }, 250L)
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("guard", "AloGemini", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "guard")
            .setContentTitle(L.tr("AloGemini dang canh"))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        val r = contentResolver
        for (k in listOf("assistant", "voice_interaction_service"))
            r.registerContentObserver(Settings.Secure.getUriFor(k), false, observer)
        r.registerContentObserver(Settings.Secure.getUriFor(Restorer.ACC_KEY), false, observer)
        r.registerContentObserver(Settings.Global.getUriFor("power_button_long_press"), false, observer)
        r.registerContentObserver(Settings.Secure.getUriFor(Restorer.VIVO_JOVI_KEY), false, observer)
        r.registerContentObserver(Settings.System.getUriFor(Restorer.VIVO_JOVI_KEY), false, observer)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }

        handler.post(periodic)
        GeminiSound.warm(this)
        bar = BarOverlay(this)
        bar.refresh()
        Restorer.prefs(this).registerOnSharedPreferenceChangeListener(prefListener)
        NoAccWatcher.sync(this)
        BankGuard.sync(this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        bar.refresh()
        if (Restorer.prefs(this).getBoolean("snd_on", false)) GeminiSound.warm(this) else GeminiSound.release()
        NoAccWatcher.sync(this)
        BankGuard.sync(this)
        return START_STICKY
    }
    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        bar.hide()
        NoAccWatcher.stop()
        BankGuard.stop(this)
        try { unregisterReceiver(screenReceiver) } catch (_: Throwable) {}
        try { Restorer.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Throwable) {}
        contentResolver.unregisterContentObserver(observer)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
