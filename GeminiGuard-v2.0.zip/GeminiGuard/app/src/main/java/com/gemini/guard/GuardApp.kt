package com.gemini.guard

import android.app.Application
import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.PRNGFixes
import org.lsposed.hiddenapibypass.HiddenApiBypass

/** Nap ngon ngu giao dien cho moi thanh phan (Activity, dich vu, receiver). */
class GuardApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // ADB tich hop dung Conscrypt cua he thong (TLS 1.3) nen can mo hidden API.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
        }
    }

    override fun onCreate() {
        super.onCreate()
        installCrashReporter()
        try { PRNGFixes.apply() } catch (_: Throwable) {}
        L.load(this)
    }

    /** Khi app van: mo man hinh hien noi dung loi (de chup gui nguoi ho tro), roi de he thong xu ly nhu thuong. */
    private fun installCrashReporter() {
        if (android.os.Process.myPid().let { pid ->
                (getSystemService(android.app.ActivityManager::class.java).runningAppProcesses ?: emptyList())
                    .firstOrNull { it.pid == pid }?.processName?.endsWith(":crash") == true
            }) return   // khong bat loi trong chinh tien trinh bao loi
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "?" }
                val text = "Gemini Guard v$ver\n" + Build.MANUFACTURER + " " + Build.MODEL +
                    " · Android " + Build.VERSION.SDK_INT + "\nluồng: " + t.name + "\n\n" +
                    e.stackTraceToString().take(6000)
                startActivity(
                    android.content.Intent(this, CrashActivity::class.java)
                        .putExtra("t", text)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                )
                Thread.sleep(400)   // cho he thong kip nhan yeu cau mo man hinh loi
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }
}
