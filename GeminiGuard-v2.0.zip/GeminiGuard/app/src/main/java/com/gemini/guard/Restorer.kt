package com.gemini.guard

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Restorer {
    const val GOOGLE_ASSIST =
        "com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService"
    const val GOOGLE_PKG = "com.google.android.googlequicksearchbox"
    const val CHATGPT_PKG = "com.openai.chatgpt"
    private val SECURE_KEYS = listOf("assistant", "voice_interaction_service")

    /**
     * App duoc GOI khi phat hien Mi AI (giong noi) hoac bam "Gọi Gemini" tren thanh dieu huong.
     * Chi Google/Gemini la tich hop that o muc he thong (VoiceInteractionService) nen giu nut
     * nguon luon mo duoc Gemini truc tiep. ChatGPT (va app khac) khong co kieu tich hop nay,
     * nen chi mo duoc bang cach mo thang app do (nhu mo mot app binh thuong), khong the thay
     * the duoc hanh vi giu nut nguon o muc he thong.
     */
    fun targetPkg(c: Context): String = prefs(c).getString("target_pkg", GOOGLE_PKG) ?: GOOGLE_PKG

    fun targetLabel(c: Context): String = when (targetPkg(c)) {
        GOOGLE_PKG -> "Google"
        CHATGPT_PKG -> "ChatGPT"
        else -> targetPkg(c)
    }

    /** Thuc hien goi tro ly muc tieu. Google: dung API an hien dung lop phu tro ly that (nhu cu).
     * Khac Google (vd ChatGPT): chi mo thang app do len, khong phai lop phu tro ly he thong that.
     * Tra ve null = thanh cong, khac null = mo ta loi. */
    fun callTarget(c: Context): String? {
        if (targetPkg(c) == GOOGLE_PKG) {
            val err = GeminiCall.show()
            if (err == null) return null
            val gem = c.packageManager.getLaunchIntentForPackage("com.google.android.apps.bard")
            return try {
                if (gem != null) { c.startActivity(gem.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); null } else err
            } catch (_: Exception) { err }
        }
        if (targetPkg(c) == CHATGPT_PKG) {
            // Man hinh tro ly cua ChatGPT (tim duoc qua adb luc bam o tile Control Center).
            // Khong phai tich hop tro ly he thong that, chi la mot Activity binh thuong cua
            // ChatGPT, nen co the bi chan goi tu app khac tren mot so ban - du phong mo app thuong.
            val i = Intent().setClassName(CHATGPT_PKG, "com.openai.voice.assistant.AssistantActivity")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { c.startActivity(i); return null } catch (_: Exception) {}
            val gen = c.packageManager.getLaunchIntentForPackage(CHATGPT_PKG)
                ?: return L.fmt("Chưa cài %s (%s)", targetLabel(c), CHATGPT_PKG)
            return try { c.startActivity(gen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); null }
            catch (e: Exception) { e.message ?: "error" }
        }
        val pkg = targetPkg(c)
        val i = c.packageManager.getLaunchIntentForPackage(pkg)
            ?: return L.fmt("Chưa cài %s (%s)", targetLabel(c), pkg)
        return try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); null }
        catch (e: Exception) { e.message ?: "error" }
    }
    private const val POWER_KEY = "power_button_long_press"

    /** vivo OriginOS: cong tac "giu nut nguon goi Jovi" (1 = bat). Nam ca o bang secure va system. */
    const val VIVO_JOVI_KEY = "vivo_jovi_power_wakeup_switch"

    fun vivoJoviPresent(c: Context): Boolean = try {
        val r = c.contentResolver
        Settings.Secure.getString(r, VIVO_JOVI_KEY) != null || Settings.System.getString(r, VIVO_JOVI_KEY) != null
    } catch (_: Throwable) { false }

    fun vivoJoviOn(c: Context): Boolean = try {
        val r = c.contentResolver
        Settings.Secure.getString(r, VIVO_JOVI_KEY) == "1" || Settings.System.getString(r, VIVO_JOVI_KEY) == "1"
    } catch (_: Throwable) { false }
    private const val POWER_VALUE = 5

    const val ACC_KEY = "enabled_accessibility_services"

    private fun enabledList(r: android.content.ContentResolver): List<String> =
        (Settings.Secure.getString(r, ACC_KEY) ?: "").split(":").filter { it.isNotBlank() }

    fun accessibilityOn(c: Context): Boolean {
        val cn = ComponentName(c, MiAiWatcher::class.java)
        return enabledList(c.contentResolver).any { ComponentName.unflattenFromString(it) == cn } &&
            Settings.Secure.getInt(c.contentResolver, "accessibility_enabled", 0) == 1
    }

    fun prefs(c: Context) = c.getSharedPreferences("guard", Context.MODE_PRIVATE)

    fun hasPermission(c: Context) =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    /** Ghi lại giá trị đúng nếu bị đổi. Trả về mô tả những gì đã sửa. */
    fun ensure(c: Context): List<String> {
        val changes = mutableListOf<String>()
        if (!hasPermission(c)) return changes
        if (cycling) return changes   // dang tat -> bat lai Google, dung can thiep
        val r = c.contentResolver
        try {
            for (k in SECURE_KEYS) {
                val cur = Settings.Secure.getString(r, k)
                if (cur != GOOGLE_ASSIST) {
                    Settings.Secure.putString(r, k, GOOGLE_ASSIST)
                    changes += "$k: [${cur ?: "null"}] -> Google"
                }
            }
            val p = Settings.Global.getInt(r, POWER_KEY, -1)
            if (p != POWER_VALUE) {
                Settings.Global.putInt(r, POWER_KEY, POWER_VALUE)
                changes += "$POWER_KEY: [$p] -> $POWER_VALUE"
            }
            // vivo: giu cong tac Jovi tren nut nguon o muc tat de nut nguon goi Gemini
            if (prefs(c).getBoolean("vivo_pin", true)) {
                if (Settings.Secure.getString(r, VIVO_JOVI_KEY) == "1") {
                    Settings.Secure.putString(r, VIVO_JOVI_KEY, "0")
                    changes += "$VIVO_JOVI_KEY (secure): [1] -> 0"
                }
                if (Settings.System.getString(r, VIVO_JOVI_KEY) == "1") {
                    Settings.System.putString(r, VIVO_JOVI_KEY, "0")
                    changes += "$VIVO_JOVI_KEY (system): [1] -> 0"
                }
            }
            // Khi "Mục kiểm tra ngân hàng" dang chu dong tat Tro nang, khong tu bat lai o day
            if (prefs(c).getBoolean("mi_on", false) && !accessibilityOn(c) && !prefs(c).getBoolean("bank_disabled_by_us", false) && !prefs(c).getBoolean("acc_tile_off", false)) {
                val cn = ComponentName(c, MiAiWatcher::class.java)
                val list = enabledList(r).filter { ComponentName.unflattenFromString(it) != cn }
                Settings.Secure.putString(r, ACC_KEY, (list + cn.flattenToString()).joinToString(":"))
                Settings.Secure.putInt(r, "accessibility_enabled", 1)
                changes += L.tr("Trợ năng MiAiWatcher: TẮT -> BẬT")
            }
        } catch (e: SecurityException) {
            changes += L.tr("Lỗi quyền: ") + e.message
        }
        if (changes.isNotEmpty()) log(c, changes.joinToString("; "))
        return changes
    }

    // ---------- Tat -> bat lai Google (giong app Gemini Restore) ----------
    @Volatile var cycling = false
    private val cycleBusy = java.util.concurrent.atomic.AtomicBoolean(false)

    /**
     * Ngat tro ly (de trong), cho, bat lai Google va dat nut nguon = 5, roi doc lai de kiem tra.
     * Co Thread.sleep nen PHAI chay tren luong nen. Tra ve mo ta ket qua.
     */
    fun cycle(c: Context): String {
        if (!hasPermission(c)) return L.tr("Chưa cấp quyền WRITE_SECURE_SETTINGS. Hãy cấp bằng ADB trước.")
        if (!cycleBusy.compareAndSet(false, true)) return L.tr("Đang chạy, chờ vài giây rồi thử lại.")
        cycling = true
        val r = c.contentResolver
        val oldAssistant = Settings.Secure.getString(r, "assistant")
        val oldService = Settings.Secure.getString(r, "voice_interaction_service")
        val oldPower = Settings.Global.getString(r, POWER_KEY)
        val msg = try {
            runCycle(c)
        } catch (e: Throwable) {
            try {
                Settings.Secure.putString(r, "voice_interaction_service", oldService)
                Settings.Secure.putString(r, "assistant", oldAssistant)
                Settings.Global.putString(r, POWER_KEY, oldPower)
            } catch (_: Throwable) {}
            L.fmt("Không hoàn tất: %s: %s. Đã trả về giá trị cũ.", e.javaClass.simpleName, e.message)
        } finally {
            cycling = false
            cycleBusy.set(false)
        }
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
        prefs(c).edit().putString("cycle_last", "$t  $msg").apply()
        log(c, L.tr("tắt→bật Google: ") + msg)
        return msg
    }

    private fun runCycle(c: Context): String {
        val r = c.contentResolver
        val cn = ComponentName.unflattenFromString(GOOGLE_ASSIST)!!
        val info = try { c.packageManager.getServiceInfo(cn, 0) } catch (_: Exception) { null }
        if (info == null || !info.enabled) return L.tr("Không tìm thấy dịch vụ trợ lý Google đang bật; chưa thay đổi gì.")

        val offMs = prefs(c).getInt("cycle_off_ms", 1500).toLong()
        Settings.Secure.putString(r, "voice_interaction_service", "")
        Settings.Secure.putString(r, "assistant", "")
        Thread.sleep(offMs)

        Settings.Secure.putString(r, "voice_interaction_service", GOOGLE_ASSIST)
        Settings.Secure.putString(r, "assistant", GOOGLE_ASSIST)
        Settings.Global.putString(r, POWER_KEY, POWER_VALUE.toString())
        Thread.sleep(1000)

        val ok = Settings.Secure.getString(r, "assistant") == GOOGLE_ASSIST &&
            Settings.Secure.getString(r, "voice_interaction_service") == GOOGLE_ASSIST &&
            Settings.Global.getString(r, POWER_KEY) == POWER_VALUE.toString()
        return if (ok) L.tr("Đã tắt → bật lại Google; đọc lại đúng 3 giá trị. Hãy thử giữ nút nguồn.")
        else L.tr("Đã chạy nhưng HyperOS chưa giữ đúng giá trị (hệ thống có thể đã tự đổi lại). Thử bấm lại.")
    }

    /** Goi tu BootReceiver (luong nen). Moi lan khoi dong may chi chay 1 lan. */
    fun cycleOnBoot(c: Context) {
        val pr = prefs(c)
        val bc = Settings.Global.getInt(c.contentResolver, "boot_count", -1)
        if (bc != -1 && bc == pr.getInt("last_cycle_boot", -2)) return
        pr.edit().putInt("last_cycle_boot", bc).apply()
        val d = pr.getInt("cycle_boot_delay_s", 0)
        if (d > 0) Thread.sleep(d * 1000L)
        cycle(c)
    }

    private fun log(c: Context, msg: String) {
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
        val old = prefs(c).getString("log", "") ?: ""
        val lines = (listOf("$t  $msg") + old.split("\n").filter { it.isNotBlank() }).take(10)
        prefs(c).edit().putString("log", lines.joinToString("\n")).apply()
    }

    fun status(c: Context): String {
        val r = c.contentResolver
        val sb = StringBuilder()
        sb.append(L.tr("Quyền WRITE_SECURE_SETTINGS: ")).append(if (hasPermission(c)) "OK" else L.tr("CHƯA CẤP")).append("\n")
        sb.append(L.tr("Trợ lý mục tiêu cho \"Gọi Gemini\": ")).append(targetLabel(c)).append(" (").append(targetPkg(c)).append(")\n")
        for (k in SECURE_KEYS) {
            val v = Settings.Secure.getString(r, k)
            sb.append(k).append(": ").append(if (v == GOOGLE_ASSIST) "Google OK" else "[" + (v ?: L.tr("trống")) + "] " + L.tr("SAI")).append("\n")
        }
        sb.append(POWER_KEY).append(": ").append(Settings.Global.getInt(r, POWER_KEY, -1)).append("\n")
        sb.append(L.tr("Trợ năng MiAiWatcher: ")).append(if (accessibilityOn(c)) L.tr("BẬT") else L.tr("TẮT")).append(if (prefs(c).getBoolean("acc_tile_off", false)) L.tr(" (tắt bằng phím tắt Control Center)") else "").append("\n")
        sb.append(L.tr("Tắt→bật Google gần nhất: ")).append(prefs(c).getString("cycle_last", "")?.ifBlank { L.tr("(chưa chạy)") } ?: L.tr("(chưa chạy)")).append("\n")
        sb.append(L.tr("\nNhật ký tự sửa (mới nhất trước):\n"))
        sb.append(prefs(c).getString("log", "")?.ifBlank { L.tr("(chưa có)") } ?: L.tr("(chưa có)"))
        return sb.toString()
    }

    /** Liet ke cac cai dat he thong lien quan tro ly / nut nguon de tim cong tac tat Mi AI. */
    fun dumpRelated(c: Context): String {
        val re = Regex("power|xiaoai|voice|assist|long_press|speech|aivoice|ai_key", RegexOption.IGNORE_CASE)
        val noise = Regex("layoutDescriptor|white_list|power_center|low_power|POWER_SAVE|perf_|powerkeep|volume_|power_supersave|superpower|lower_power", RegexOption.IGNORE_CASE)
        val sb = StringBuilder()
        val tables = listOf(
            "global" to Settings.Global.CONTENT_URI,
            "secure" to Settings.Secure.CONTENT_URI,
            "system" to Settings.System.CONTENT_URI
        )
        for ((n, u) in tables) {
            try {
                c.contentResolver.query(u, arrayOf("name", "value"), null, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val k = cur.getString(0) ?: continue
                        if (re.containsMatchIn(k) && !noise.containsMatchIn(k)) sb.append(n).append(": ").append(k).append(" = ").append(cur.getString(1)).append("\n")
                    }
                }
            } catch (e: Throwable) { sb.append(n).append(L.tr(": lỗi ")).append(e.message).append("\n") }
        }
        return sb.toString().ifBlank { L.tr("(không tìm thấy)") }.take(12000)
    }
}
