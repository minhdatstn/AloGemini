package com.gemini.guard

import android.content.Context

/** Mat tien chung: dung Shizuku neu co quyen, khong thi dung ADB tich hop. */
object Shell {
    fun ready(): Boolean = ShizukuHelper.hasPerm() || AdbSelf.linked

    fun via(): String = when {
        ShizukuHelper.hasPerm() -> "Shizuku"
        AdbSelf.linked -> "ADB"
        else -> ""
    }

    fun exec(cmd: String): String =
        if (ShizukuHelper.hasPerm()) ShizukuHelper.exec(cmd) else AdbSelf.exec(cmd)

    /** Tu cap quyen thay cho lenh adb tren may tinh. Chay tren luong nen. */
    fun grantAll(c: Context): String {
        val pkg = c.packageName
        val sb = StringBuilder()
        try {
            val r1 = exec("pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
            if (!Restorer.hasPermission(c)) sb.append(L.tr("Không cấp được WRITE_SECURE_SETTINGS: ")).append(r1)
            else sb.append(L.tr("Đã cấp WRITE_SECURE_SETTINGS"))
            exec("appops set $pkg GET_USAGE_STATS allow")
            exec("appops set $pkg SYSTEM_ALERT_WINDOW allow")
            sb.append(L.tr(" · đã thử cấp Truy cập sử dụng và Hiển thị trên ứng dụng khác"))
        } catch (e: Throwable) {
            sb.append(L.tr("Lỗi: ")).append(e.message)
        }
        return sb.toString()
    }
}
