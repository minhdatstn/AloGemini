package com.gemini.guard

import android.app.Activity
import android.app.AlertDialog
import android.view.Gravity
import android.widget.ImageView
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private val BG = 0xFFF1F3F8.toInt()
private val CARD = Color.WHITE
private val INK = 0xFF1B1D22.toInt()
private val MUTED = 0xFF6B7280.toInt()
private val ACCENT = 0xFF3B6FE0.toInt()
private val TONAL = 0xFFE6EDFC.toInt()
private val GOOD = 0xFF1E8E3E.toInt()
private val BAD = 0xFFC62828.toInt()
private val FIELD = 0xFFF4F5F9.toInt()
private val LINE = 0xFFD9DCE5.toInt()

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var ctsPkg: EditText
    private lateinit var miPkgs: EditText
    private lateinit var miInc: EditText
    private lateinit var miExc: EditText
    private lateinit var bankPkgs: EditText
    private lateinit var sndCls: EditText
    private lateinit var warnCard: LinearLayout
    private lateinit var stateBox: LinearLayout
    private lateinit var shzCmd: EditText
    private lateinit var shzCode: EditText
    private lateinit var shzPort: EditText
    private lateinit var pillShz: TextView
    private lateinit var subShz: TextView
    private lateinit var pillWifi: TextView
    private lateinit var pillAuto: TextView
    private lateinit var pillNotif: TextView
    private lateinit var btnStop: Button
    private lateinit var progress: TextView
    private lateinit var shzOut: TextView

    private val tabBtns = mutableListOf<TextView>()
    private val tabPanes = mutableListOf<LinearLayout>()
    private lateinit var mainScroll: ScrollView

    private fun prefs() = Restorer.prefs(this)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun pushService() {
        Restorer.ensure(this)
        if (prefs().getBoolean("enabled", true) || prefs().getBoolean("bar", false))
            startForegroundService(Intent(this, GuardService::class.java))
        else stopService(Intent(this, GuardService::class.java))
    }

    // ---------- Hỗ trợ ----------
    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, L.tr("Không mở được liên kết: ") + e.message, Toast.LENGTH_LONG).show() }
    }

    /** Luu anh QR vao thu vien (Pictures/AloGemini) de quet bang ung dung ngan hang tren cung dien thoai. */
    private fun saveQr() {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) {
                Toast.makeText(this, L.tr("Android thấp: hãy chụp màn hình mã QR rồi quét từ thư viện"), Toast.LENGTH_LONG).show(); return
            }
            val bmp = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.qr_donate)
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "AloGemini_QR_mi_tom.png")
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/AloGemini")
            }
            val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException(L.tr("không tạo được tệp"))
            contentResolver.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, L.tr("Đã lưu ảnh QR vào thư viện (Pictures/AloGemini)"), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, L.tr("Không lưu được ảnh: ") + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private fun showSupport() {
        val url = "https://www.facebook.com/datbeans512/"
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        body.addView(label(L.tr("Cần hỗ trợ cài đặt hoặc gặp lỗi? Liên hệ admin AloGemini qua Facebook để được trợ giúp."), 14f, INK))
        body.addView(label("Facebook admin", 13f, MUTED, true).apply { setPadding(0, dp(14), 0, 0) })
        body.addView(TextView(this).apply {
            text = url; textSize = 14f; setTextColor(ACCENT)
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            setPadding(0, dp(4), 0, dp(4))
            setOnClickListener { openUrl(url) }
        })
        body.addView(label(
            L.tr("Khi nhờ hỗ trợ, bạn nên gửi kèm ảnh chụp màn hình và nút \"Sao chép trạng thái\" ") +
                L.tr("(mục Khác & Chẩn đoán)."),
            12f, MUTED).apply { setPadding(0, dp(12), 0, 0) })

        // Ung ho admin
        body.addView(View(this).apply { setBackgroundColor(0x1F000000) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(18) })
        body.addView(label(L.tr("Hỗ trợ admin gói mì tôm"), 16f, INK, true).apply { setPadding(0, dp(16), 0, 0) })
        body.addView(label(L.tr("Nếu thấy app hữu ích, bạn có thể mời admin một gói mì tôm bằng cách quét mã QR bên dưới (mọi ứng dụng ngân hàng và ví đều quét được). Không bắt buộc nhé."), 13f, MUTED)
            .apply { setPadding(0, dp(6), 0, dp(10)) })
        body.addView(ImageView(this).apply {
            setImageResource(R.drawable.qr_donate)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        btn(body, L.tr("Lưu ảnh QR vào thư viện"), top = 8) { saveQr() }
        body.addView(View(this), LinearLayout.LayoutParams(1, dp(8)))

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
            .setTitle(L.tr("Hỗ trợ"))
            .setView(ScrollView(this).apply { addView(body) })
            .setPositiveButton(L.tr("Mở Facebook")) { _, _ -> openUrl(url) }
            .setNeutralButton(L.tr("Sao chép link")) { _, _ -> copy("facebook", url, L.tr("Đã sao chép liên kết")) }
            .setNegativeButton(L.tr("Đóng"), null)
            .show()
    }

    // ---------- Thành phần giao diện ----------
    private fun shape(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun card(root: LinearLayout, title: String, desc: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 18)
            setPadding(dp(18), dp(16), dp(18), dp(18))
            elevation = dp(1).toFloat()
        }
        c.addView(label(title, 17f, INK, true))
        if (desc != null) c.addView(label(desc, 13f, MUTED).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(c, lp(14))
        return c
    }

    private fun sw(p: LinearLayout, text: String, hint: String?, key: String, def: Boolean) {
        val s = Switch(this).apply {
            this.text = text; textSize = 15f; setTextColor(INK)
            isChecked = prefs().getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs().edit().putBoolean(key, on).apply(); pushService() }
        }
        p.addView(s, lp(14))
        if (hint != null) p.addView(label(hint, 12f, MUTED).apply { setPadding(0, dp(2), 0, 0) }, lp(0))
    }

    /** Chon ngon ngu giao dien: tu dong / English / Tieng Viet. */
    private fun langRow(p: LinearLayout) {
        val opts = listOf("auto" to "Auto / Tự động", "en" to "English", "vi" to "Tiếng Việt")
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(label("Language / Ngôn ngữ", 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val cur = prefs().getString("lang", "auto") ?: "auto"
        row.addView(label(opts.firstOrNull { it.first == cur }?.second ?: opts[0].second, 14f, ACCENT, true))
        row.setOnClickListener {
            val idx = opts.indexOfFirst { it.first == cur }.coerceAtLeast(0)
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setTitle("Language / Ngôn ngữ")
                .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), idx) { d, which ->
                    prefs().edit().putString("lang", opts[which].first).apply()
                    L.load(this)
                    d.dismiss()
                    recreate()
                }
                .setNegativeButton("Cancel / Hủy", null)
                .show()
        }
        p.addView(row)
    }

    /** Dong chon 1 trong nhieu lua chon (hop thoai), dung chung cho moi noi can "picker". */
    private fun pickRow(p: LinearLayout, text: String, key: String, opts: List<Pair<String, String>>, default: String, onChange: (() -> Unit)? = null) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(label(text, 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun labelOf(v: String) = opts.firstOrNull { it.first == v }?.second ?: v
        val cur = prefs().getString(key, default) ?: default
        val value = label(labelOf(cur), 14f, ACCENT, true)
        row.addView(value)
        row.setOnClickListener {
            val now = prefs().getString(key, default) ?: default
            val idx = opts.indexOfFirst { it.first == now }.coerceAtLeast(0)
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setTitle(text)
                .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), idx) { d, which ->
                    prefs().edit().putString(key, opts[which].first).apply()
                    value.text = opts[which].second
                    d.dismiss()
                    onChange?.invoke()
                    refresh()
                }
                .setNegativeButton(L.tr("Hủy"), null)
                .show()
        }
        p.addView(row)
    }

    /** Dong chon hanh dong cho cu chi (hop thoai chon 1). */
    private fun choice(p: LinearLayout, text: String, key: String) {
        val opts = BarOverlay.ACTIONS
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(label(text, 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun labelOf(v: String) = L.tr(opts.firstOrNull { it.first == v }?.second ?: v)
        val value = label(labelOf(BarOverlay.currentAction(prefs(), key)), 14f, ACCENT, true)
        row.addView(value)
        row.setOnClickListener {
            val cur = BarOverlay.currentAction(prefs(), key)
            val idx = opts.indexOfFirst { it.first == cur }.coerceAtLeast(0)
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setTitle(text)
                .setSingleChoiceItems(opts.map { L.tr(it.second) }.toTypedArray(), idx) { d, which ->
                    prefs().edit().putString(key, opts[which].first).apply()
                    value.text = L.tr(opts[which].second)
                    d.dismiss()
                }
                .setNegativeButton(L.tr("Hủy"), null)
                .show()
        }
        p.addView(row)
    }

    private fun seek(p: LinearLayout, text: String, unit: String, key: String, max: Int, def: Int) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(label(text, 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val v = label("${prefs().getInt(key, def)}$unit", 14f, ACCENT, true)
        row.addView(v)
        p.addView(row, lp(16))
        val sb = SeekBar(this).apply {
            this.max = max; progress = prefs().getInt(key, def)
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, u: Boolean) { v.text = "$pr$unit" }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {
                    prefs().edit().putInt(key, s.progress).apply(); pushService()
                }
            })
        }
        p.addView(sb, lp(0))
    }

    private fun btn(p: LinearLayout, text: String, primary: Boolean = false, top: Int = 12, action: () -> Unit): Button {
        val b = Button(this).apply {
            this.text = text; isAllCaps = false; textSize = 14f
            setTextColor(if (primary) Color.WHITE else ACCENT)
            stateListAnimator = null; minimumHeight = dp(46)
            background = RippleDrawable(
                ColorStateList.valueOf(0x33000000),
                shape(if (primary) ACCENT else TONAL, 12), shape(Color.WHITE, 12)
            )
            setOnClickListener { action(); refresh() }
        }
        p.addView(b, lp(top))
        return b
    }

    private fun field(p: LinearLayout, title: String, hint: String, value: String): EditText {
        p.addView(label(title, 12f, MUTED), lp(16))
        val e = EditText(this).apply {
            this.hint = hint; setText(value); textSize = 14f; setTextColor(INK)
            setSingleLine(true)
            background = shape(FIELD, 12, LINE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        p.addView(e, lp(6))
        return e
    }

    private fun stateRow(ok: Boolean, name: String, okText: String, badText: String): TextView {
        val color = if (ok) GOOD else BAD
        val sb = SpannableStringBuilder("●  ")
        sb.setSpan(ForegroundColorSpan(color), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append(name).append(":  ")
        val start = sb.length
        sb.append(if (ok) okText else badText)
        sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return TextView(this).apply { text = sb; textSize = 14f; setTextColor(INK); setPadding(0, dp(3), 0, dp(3)) }
    }

    private fun copy(name: String, value: CharSequence, toast: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(name, value))
        Toast.makeText(this, toast, Toast.LENGTH_SHORT).show()
    }

    private fun openAppSettings() =
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))

    private fun bindPref(e: EditText, key: String) {
        e.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                prefs().edit().putString(key, s?.toString()?.trim() ?: "").apply()
            }
        })
    }

    private fun learnMode(mode: String) {
        prefs().edit().putString("learn_mode", mode)
            .putLong("learn_until", android.os.SystemClock.elapsedRealtime() + 20000L).apply()
        Toast.makeText(this,
            if (mode == "inc") L.tr("Hãy gọi Jovi hoặc BlueLM bằng giọng nói ngay (trong 20 giây), chỉ cần nói câu gọi.")
            else L.tr("Hãy mở app Jovi hoặc BlueLM ngay (trong 20 giây) để loại trừ cửa sổ đó."),
            Toast.LENGTH_LONG).show()
    }

    private fun openAutostart() {
        val tries = listOf(
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.PurviewTabActivity",
            "com.iqoo.secure" to "com.iqoo.secure.MainActivity"
        )
        for ((pkg, cls) in tries) {
            try {
                startActivity(Intent().setComponent(ComponentName(pkg, cls)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {}
        }
        openAppSettings()
        Toast.makeText(this, L.tr("Mở iManager → Quản lý tự khởi động, rồi bật AloGemini."), Toast.LENGTH_LONG).show()
    }

    /** Chuyen doi giua cac muc (Tab). */
    private fun selectTab(idx: Int) {
        prefs().edit().putInt("ui_tab", idx).apply()
        for (i in tabPanes.indices) {
            tabPanes[i].visibility = if (i == idx) View.VISIBLE else View.GONE
            val b = tabBtns[i]
            val active = (i == idx)
            b.setTextColor(if (active) Color.WHITE else INK)
            b.background = shape(if (active) ACCENT else CARD, 20, if (active) null else LINE)
            b.elevation = if (active) dp(2).toFloat() else 0f
        }
        if (::mainScroll.isInitialized) mainScroll.smoothScrollTo(0, 0)
    }

    // ---------- Màn hình chính (Chia theo từng mục) ----------
    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs().edit().remove("evlog").remove("ev_log").apply()   // don nhat ky su kien cu (tinh nang da go)
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        window.statusBarColor = BG
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "?" }

        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // Phần đầu cố định (Header + Thanh chọn mục)
        val topHeader = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(10))
            setBackgroundColor(BG)
        }

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
        }
        head.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(10) })
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(label("AloGemini", 24f, INK, true))
        titleCol.addView(label(L.fmt("vivo OriginOS · v%s · by Dragon", ver), 12f, MUTED))
        head.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply {
            text = L.tr("Hỗ trợ"); textSize = 13f; setTextColor(ACCENT); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = shape(TONAL, 20)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { showSupport() }
        })
        topHeader.addView(head)

        // Thanh danh mục ngang (Segmented Pills)
        val tabNames = listOf(
            L.tr("Tổng quan"),
            L.tr("Kết nối & Quyền"),
            L.tr("Jovi & Ngân hàng"),
            L.tr("Thanh AI & Âm thanh"),
            L.tr("Khác")
        )
        val tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(12), 0, dp(2))
        }
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tabBtns.clear()
        tabPanes.clear()
        for ((i, name) in tabNames.withIndex()) {
            val pillBtn = TextView(this).apply {
                text = name
                textSize = 13.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(9), dp(16), dp(9))
                setOnClickListener { selectTab(i) }
            }
            val lpBtn = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) leftMargin = dp(8)
            }
            tabRow.addView(pillBtn, lpBtn)
            tabBtns.add(pillBtn)
        }
        tabScroll.addView(tabRow)
        topHeader.addView(tabScroll)
        screen.addView(topHeader, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Vùng nội dung cuộn cho từng mục
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(36))
        }

        fun makePane(): LinearLayout {
            val p = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
            }
            root.addView(p, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            tabPanes.add(p)
            return p
        }

        val pOverview = makePane()
        val pShizuku = makePane()
        val pJovi = makePane()
        val pBarSound = makePane()
        val pTools = makePane()

        // ==================== MỤC 1: TỔNG QUAN ====================
        warnCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(0xFFFDECEA.toInt(), 18, 0xFFF3B9B3.toInt())
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }
        warnCard.addView(label(L.tr("Chưa cấp quyền ghi cài đặt bảo mật"), 16f, BAD, true))
        warnCard.addView(label(
            L.tr("Thiếu quyền WRITE_SECURE_SETTINGS nên app không giữ được Google làm trợ lý ") +
                L.tr("(máy sẽ hiện bảng “Complete action using” và mở app Google). Hãy cấp bằng ADB. ") +
                L.tr("Khi cập nhật, cài đè lên bản cũ và đừng gỡ cài đặt, vì gỡ sẽ mất quyền."),
            13f, INK).apply { setPadding(0, dp(6), 0, 0) })
        btn(warnCard, L.tr("Tự cấp quyền (Shizuku hoặc ADB tích hợp)"), primary = true) { grantViaShizuku() }
        btn(warnCard, L.tr("Mở mục Kết nối & Quyền (ghép đôi ADB)"), top = 8) { selectTab(1) }
        btn(warnCard, L.tr("Sao chép lệnh ADB cấp quyền"), top = 8) {
            copy("adb", "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS", L.tr("Đã sao chép lệnh ADB"))
        }
        pOverview.addView(warnCard, lp(10))

        // Trạng thái nhanh
        val st = card(pOverview, L.tr("Trạng thái"))
        stateBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        st.addView(stateBox, lp(8))

        // Giữ Gemini làm trợ lý
        val c1 = card(pOverview, L.tr("Giữ Gemini làm trợ lý"),
            L.tr("Canh cài đặt OriginOS. Nếu hệ thống đổi trợ lý hoặc bật lại Jovi trên nút nguồn, app ghi lại Google và tắt công tắc Jovi."))
        sw(c1, L.tr("Canh nền và tự khôi phục Google"), null, "enabled", true)
        btn(c1, L.tr("Khôi phục ngay"), primary = true) {
            val ch = Restorer.ensure(this)
            Toast.makeText(this, if (ch.isEmpty()) L.tr("Mọi thứ đã đúng") else L.fmt("Đã sửa %d mục", ch.size), Toast.LENGTH_SHORT).show()
        }

        btn(c1, "Restart Google", top = 8) {
            Toast.makeText(this, L.tr("Đang tắt → bật lại, giữ app mở vài giây…"), Toast.LENGTH_SHORT).show()
            Thread {
                val res = Restorer.cycle(this)
                runOnUiThread { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); refresh() }
            }.start()
        }
        sw(c1, L.tr("Tự tắt → bật lại Google sau khi khởi động máy"),
            L.tr("Để giữ nút nguồn gọi Gemini thay vì Jovi sau mỗi lần khởi động. Cần cho phép tự khởi động."),
            "cycle_boot", true)
        seek(c1, L.tr("Đợi sau khi máy khởi động xong"), L.tr(" giây"), "cycle_boot_delay_s", 30, 0)
        btn(c1, L.tr("Mở quản lý tự khởi động (iManager)"), top = 8) { openAutostart() }
        sw(c1, L.tr("Giữ tắt Jovi trên nút nguồn"),
            L.tr("Nút nguồn gọi Gemini khi công tắc Jovi tắt. Nếu OriginOS bật lại (vivo_jovi_power_wakeup_switch = 1) thì app tắt lại ngay."),
            "vivo_pin", true)

        // ==================== MỤC 2: KẾT NỐI & QUYỀN ====================
        shizukuSection(pShizuku)

        val cz = card(pShizuku, L.tr("Chạy lệnh shell (Shizuku hoặc ADB tích hợp)"),
            L.tr("Chạy lệnh qua Shizuku (nếu có) hoặc ADB tích hợp đã ghép đôi ở trên. Nút dưới chỉ dùng khi bạn cài app Shizuku riêng."))
        btn(cz, L.tr("Cấp quyền Shizuku cho app"), primary = true) {
            Toast.makeText(this, ShizukuHelper.request(), Toast.LENGTH_LONG).show()
        }
        btn(cz, L.tr("Tự cấp quyền ADB cho app qua Shizuku"), top = 8) { grantViaShizuku() }
        shzCmd = field(cz, L.tr("Lệnh shell"), "pm list packages -3", "")
        btn(cz, L.tr("Chạy lệnh"), top = 10) { runShizukuCmd(shzCmd.text.toString()) }
        shzOut = TextView(this).apply {
            textSize = 12f; setTextColor(MUTED); typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            background = shape(FIELD, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        cz.addView(shzOut, lp(10))

        // ==================== MỤC 3: JOVI & NGÂN HÀNG ====================
        val c3 = card(pJovi, L.tr("Gọi Gemini khi Jovi hoặc BlueLM bật lên") + L.tr(" (không dùng được ngân hàng và VNeID, muốn dùng phải tắt đi)"),
            L.tr("Khi phát hiện Jovi hoặc BlueLM (giữ nút nguồn, gọi giọng nói…), app đóng nó (bấm Back và chạm vào chỗ trống) rồi gọi Gemini lên thay thế. Cần bật Trợ năng cho AloGemini – nhiều app ngân hàng và VNeID sẽ chặn hoặc cảnh báo khi Trợ năng đang bật, nên tắt mục này (và tắt Trợ năng) trước khi dùng các app đó."))
        sw(c3, L.tr("Tự gọi Gemini khi Jovi hoặc BlueLM bật lên"), null, "mi_on", false)
        pickRow(c3, L.tr("Gọi đến"), "target_pkg",
            listOf(Restorer.GOOGLE_PKG to "Gemini (Google)", Restorer.CHATGPT_PKG to "ChatGPT"), Restorer.GOOGLE_PKG)
        c3.addView(label(L.tr("Chỉ áp dụng cho việc gọi tự động này và nút \"Gọi Gemini\" trên thanh điều hướng. Google là trợ lý duy nhất tích hợp được ở mức hệ thống, nên giữ nút nguồn sẽ luôn mở Gemini dù chọn gì ở đây. ChatGPT không tích hợp trợ lý hệ thống nên app gọi thẳng vào màn hình trợ lý của ChatGPT (tìm được qua adb) – có thể bị chặn trên một số bản ChatGPT, lúc đó app sẽ mở app ChatGPT bình thường thay thế."), 12f, MUTED).apply { setPadding(0, dp(2), 0, dp(6)) })
        seek(c3, L.tr("Vị trí chạm – ngang"), "%", "mi_tx", 100, 8)
        seek(c3, L.tr("Vị trí chạm – dọc"), "%", "mi_ty", 100, 10)
        seek(c3, L.tr("Chờ trước khi chạm đóng Jovi (0 = nhanh nhất)"), " ms", "mi_tapwait", 400, 0)
        seek(c3, L.tr("Độ trễ trước khi gọi Gemini"), " ms", "mi_delay", 1500, 350)
        miPkgs = field(c3, L.tr("Tên gói Jovi / BlueLM (cách nhau bằng dấu phẩy)"), MiAiWatcher.DEFAULT_PKGS,
            prefs().getString("mi_pkgs", MiAiWatcher.DEFAULT_PKGS) ?: "")
        miInc = field(c3, L.tr("Chỉ gọi Gemini khi cửa sổ trợ lý là (để trống = mọi cửa sổ)"), L.tr("Để trống = mọi cửa sổ"), prefs().getString("mi_inc", MiAiWatcher.DEFAULT_INC) ?: "")
        bindPref(miInc, "mi_inc")
        miExc = field(c3, L.tr("Bỏ qua khi cửa sổ trợ lý là (mở app Jovi, cài đặt…)"), L.tr("Để trống = không bỏ qua cửa sổ nào"), prefs().getString("mi_exc", MiAiWatcher.DEFAULT_EXC) ?: "")
        bindPref(miExc, "mi_exc")
        btn(c3, L.tr("Đặt lại bộ lọc về mặc định"), top = 12) {
            prefs().edit().remove("mi_inc").remove("mi_exc").remove("learn_mode").apply()
            refresh()
        }
        btn(c3, L.tr("Mở cài đặt Trợ năng"), primary = true) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(c3, L.tr("Cho phép cài đặt bị hạn chế (Android 13+)"), top = 8) { openAppSettings() }

        val cb = card(pJovi, L.tr("Tự tắt Trợ năng cho ngân hàng / VNeID"),
            L.tr("Khi mở một app trong danh sách dưới đây, AloGemini tự tắt riêng dịch vụ Trợ năng của chính nó (các dịch vụ Trợ năng khác, nếu có, không bị ảnh hưởng), để app đó không cảnh báo \"rủi ro mất tiền\". Rời khỏi app đó vài trăm mili-giây là Trợ năng tự bật lại. Dùng chung kỹ thuật \"Truy cập sử dụng\" với Mục kiểm tra bên dưới, nên cũng chỉ phát hiện theo kiểu hỏi định kỳ chứ không tức thì."))
        sw(cb, L.tr("Bật tự động tắt/bật"), null, "bank_guard_on", false)
        run {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
            val ok = NoAccWatcher.hasUsageAccess(this)
            row.addView(label(L.tr("Quyền \"Truy cập sử dụng\": ") + (if (ok) "OK" else L.tr("CHƯA CẤP")), 13f, if (ok) INK else MUTED),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            cb.addView(row)
        }
        btn(cb, L.tr("Mở quyền Truy cập sử dụng"), top = 6) { NoAccWatcher.openUsageSettings(this); refresh() }
        bankPkgs = field(cb, L.tr("Tên gói ngân hàng / VNeID (cách nhau bằng dấu phẩy)"), "vd: com.tpb.mb.gprsandroid, com.vnptit.vnp.vneid", prefs().getString("bank_pkgs", "") ?: "")
        bindPref(bankPkgs, "bank_pkgs")
        cb.addView(label(L.tr("Mẹo tìm tên gói: chụp màn hình trong lúc mở app đó – Android tự đặt tên file ảnh theo tên gói, ví dụ Screenshot_..._com_tpb_mb_gprsandroid.jpg nghĩa là tên gói là com.tpb.mb.gprsandroid (đổi dấu _ cuối thành dấu chấm)."), 12f, MUTED).apply { setPadding(0, dp(4), 0, dp(6)) })
        seek(cb, L.tr("Khoảng hỏi lại (càng nhỏ càng nhanh, càng tốn pin)"), " ms", "bank_poll_ms", 1500, 500)
        run {
            val off = prefs().getBoolean("bank_disabled_by_us", false)
            val tileOff = prefs().getBoolean("acc_tile_off", false)
            val msg = when {
                off -> L.tr("Đang tắt Trợ năng vì đang dùng app trong danh sách")
                tileOff -> L.tr("Trợ năng đang tắt bằng phím tắt Control Center, hãy bật lại ở phím tắt đó khi cần đóng Jovi")
                else -> L.tr("Trợ năng đang theo trạng thái bình thường")
            }
            cb.addView(label(msg, 13f, if (off || tileOff) ACCENT else MUTED).apply { setPadding(0, dp(4), 0, 0) })
        }
        cb.addView(label(L.tr("Phím tắt thủ công: mở Control Center, bấm Chỉnh sửa (biểu tượng bút chì) rồi kéo ô \"Trợ năng AloGemini\" vào (nằm trong mục Phím nhanh ứng dụng, có thể phải cuộn xuống). Nếu không thấy ô, nhấn giữ icon app AloGemini và chọn \"Bật/tắt Trợ năng\", có thể kéo mục đó ra màn hình chính. Bấm để tắt Trợ năng NGAY TRƯỚC khi mở app ngân hàng / VNeID, chắc hơn tự động vì không phải chờ hỏi định kỳ. Cần đã cấp quyền WRITE_SECURE_SETTINGS."), 12f, MUTED).apply { setPadding(0, dp(8), 0, 0) })

        val ct = card(pJovi, L.tr("Gọi giọng nói AI (không cần quyền Trợ năng – vẫn dùng được VNeID và ngân hàng, nhưng hiệu ứng không được tốt)"),
            L.tr("Thử phát hiện Jovi hoặc BlueLM và gọi Gemini mà KHÔNG bật dịch vụ Trợ năng, để tránh bị app ngân hàng / ví điện tử cảnh báo \"rủi ro mất tiền\". Dùng quyền \"Truy cập sử dụng\" để biết app nào vừa lên nền trước, thay cho Trợ năng. Vì không có Trợ năng nên app không bấm Back hay chạm màn hình được, chỉ thử tắt tiến trình Jovi rồi gọi Gemini chồng lên – CÓ THỂ không đóng được Jovi, hãy bấm \"Thử ngay\" để kiểm tra trước khi tin dùng."))
        ct.addView(label(L.tr("Đây là tính năng thử nghiệm, độc lập với phần Trợ năng ở trên. Chỉ nên bật MỘT trong hai cách để tránh gọi Gemini hai lần."), 12f, MUTED).apply { setPadding(0, dp(2), 0, dp(10)) })
        sw(ct, L.tr("Bật thử nghiệm (không dùng Trợ năng)"), null, "noacc_on", false)
        run {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
            val ok = NoAccWatcher.hasUsageAccess(this)
            row.addView(label(L.tr("Quyền \"Truy cập sử dụng\": ") + (if (ok) "OK" else L.tr("CHƯA CẤP")), 13f, if (ok) INK else MUTED),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ct.addView(row)
        }
        btn(ct, L.tr("Mở quyền Truy cập sử dụng"), top = 6) { NoAccWatcher.openUsageSettings(this); refresh() }
        seek(ct, L.tr("Khoảng hỏi lại (càng nhỏ càng nhanh, càng tốn pin)"), " ms", "noacc_poll_ms", 1000, 300)
        seek(ct, L.tr("Chờ trước khi gọi Gemini"), " ms", "noacc_delay_ms", 1000, 150)
        btn(ct, L.tr("Thử ngay (giả lập phát hiện Jovi)"), top = 8) { NoAccWatcher.test(this) }

        // ==================== MỤC 4: THANH AI & ÂM THANH ====================
        val c2 = card(pBarSound, L.tr("Thanh điều hướng AI"),
            L.tr("Thanh nhỏ nổi ở đáy màn hình. Chọn việc cho từng cử chỉ bên dưới."))
        sw(c2, L.tr("Bật thanh điều hướng AI"), null, "bar", false)
        btn(c2, L.tr("Cấp quyền hiển thị trên ứng dụng khác")) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        ctsPkg = field(c2, L.tr("Tên gói Circle to Search"), "com.parallelc.micts", prefs().getString("cts_pkg", "com.parallelc.micts") ?: "")
        choice(c2, L.tr("Chạm đúp"), "bar_dt")
        choice(c2, L.tr("Giữ"), "bar_lp")
        seek(c2, L.tr("Chiều rộng"), "%", "bar_w", 100, 40)
        seek(c2, L.tr("Chiều cao"), " dp", "bar_h", 60, 20)
        seek(c2, L.tr("Cách đáy"), " dp", "bar_y", 60, 0)
        seek(c2, L.tr("Độ đậm (0 = vô hình)"), "%", "bar_a", 100, 30)

        val c4 = card(pBarSound, L.tr("Hiệu ứng âm thanh và rung"),
            L.tr("Phát âm thanh / rung nhẹ khi Gemini hiện lên: giữ nút nguồn, gọi giọng nói (qua Jovi) hoặc dùng thanh. Cần bật Trợ năng để nhận ra khi giữ nút nguồn."))
        sw(c4, L.tr("Phát âm thanh khi Gemini hiện lên"), null, "snd_on", false)
        seek(c4, L.tr("Âm lượng hiệu ứng"), "%", "snd_vol", 100, 100)
        seek(c4, L.tr("Khuếch đại thêm (0 = tắt)"), " dB", "snd_gain", 15, 0)
        seek(c4, L.tr("Bỏ qua đầu âm thanh để bớt trễ"), " ms", "snd_skip", 600, 0)
        seek(c4, L.tr("Chống lặp âm thanh"), L.tr(" giây"), "snd_gap_s", 10, 3)
        sndCls = field(c4, L.tr("Lọc tên cửa sổ Google (tùy chọn)"), L.tr("Để trống = mọi cửa sổ"), prefs().getString("snd_cls", "") ?: "")
        btn(c4, L.tr("Thử âm thanh"), primary = true) { GeminiSound.play(this, force = true) }
        sw(c4, L.tr("Rung nhẹ khi Gemini hiện lên"), L.tr("Máy rung ngắn tạo cảm giác cửa sổ bật ra. Dùng chung bộ lọc cửa sổ và chống lặp với âm thanh ở trên."), "vib_on", false)
        seek(c4, L.tr("Độ mạnh rung"), "%", "vib_str", 100, 60)
        seek(c4, L.tr("Thời gian rung"), " ms", "vib_ms", 80, 25)
        btn(c4, L.tr("Thử rung"), top = 8) { Haptic.pop(this, force = true) }

        // ==================== MỤC 5: KHÁC & CHẨN ĐOÁN ====================
        val c5 = card(pTools, L.tr("Công cụ và chẩn đoán"))
        langRow(c5)
        btn(c5, L.tr("Cài đặt pin / tự khởi động của app"), top = 14) { openAppSettings() }
        btn(c5, L.tr("Sao chép cài đặt Jovi / nút nguồn"), top = 8) {
            copy("settings", Restorer.dumpRelated(this), L.tr("Đã sao chép – dán vào chat để gửi người hỗ trợ"))
        }
        btn(c5, L.tr("Sao chép trạng thái"), top = 8) { copy("status", status.text, L.tr("Đã sao chép")) }
        status = TextView(this).apply {
            textSize = 12f; setTextColor(MUTED); typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            background = shape(FIELD, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        c5.addView(status, lp(14))

        root.addView(label("AloGemini v$ver · by Dragon", 12f, MUTED).apply { gravity = android.view.Gravity.CENTER },
            lp(22))

        mainScroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        screen.addView(mainScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(screen)
        val savedTab = prefs().getInt("ui_tab", 0).coerceIn(0, tabPanes.size - 1)
        selectTab(savedTab)
        pushService()
    }

    // ---------- Phan Shizuku / ADB tich hop ----------
    private fun newPill() = TextView(this).apply {
        textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(4), dp(10), dp(4))
    }

    private fun pill(t: TextView, text: String, ok: Boolean?) {
        val fg: Int
        val bg: Int
        when (ok) {
            true -> { fg = GOOD; bg = 0xFFE3F4E8.toInt() }
            false -> { fg = BAD; bg = 0xFFFDECEA.toInt() }
            else -> { fg = MUTED; bg = 0xFFEDEEF2.toInt() }
        }
        t.text = "●  " + L.tr(text); t.setTextColor(fg); t.background = shape(bg, 14)
    }

    private fun rowWithPill(p: LinearLayout, title: String, pill: TextView, top: Int) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r.addView(label(title, 15f, INK, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(pill)
        p.addView(r, lp(top))
    }

    private fun plainCard(root: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 18)
            setPadding(dp(18), dp(16), dp(18), dp(18))
            elevation = dp(1).toFloat()
        }
        root.addView(c, lp(14))
        return c
    }

    private fun note(p: LinearLayout, t: String, color: Int = MUTED, sp: Float = 13f, top: Int = 6) {
        p.addView(label(t, sp, color), lp(top))
    }

    private fun openDev() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
        catch (_: Throwable) { startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) }
    }

    private fun enableNotif() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        else
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
    }

    private fun wifiOn(): Boolean = try {
        val cm = getSystemService(android.net.ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
    } catch (_: Throwable) { false }

    private fun checkLink() {
        AdbSelf.log(L.tr("Đang kiểm tra kết nối…"))
        Thread {
            val res = if (ShizukuHelper.hasPerm()) L.tr("Shizuku đã sẵn sàng") else AdbSelf.connect(this)
            runOnUiThread { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); refresh() }
        }.start()
    }

    private fun disconnectAll() {
        Thread {
            AdbSelf.stopPairing(this)
            AdbSelf.disconnect()
            val msg: String
            var needManual = false
            if (Restorer.hasPermission(this)) {
                msg = try {
                    Settings.Global.putInt(contentResolver, "adb_wifi_enabled", 0)
                    Settings.Global.putInt(contentResolver, "adb_enabled", 0)
                    Settings.Global.putInt(contentResolver, "development_settings_enabled", 0)
                    L.tr("Đã ngắt kết nối và tắt Gỡ lỗi không dây, Gỡ lỗi USB, Tùy chọn nhà phát triển.")
                } catch (e: Throwable) { needManual = true; L.tr("Không tắt được: ") + e.message }
            } else {
                needManual = true
                msg = L.tr("Đã ngắt kết nối. Chưa có quyền ghi cài đặt bảo mật nên hãy tự tắt trong Tùy chọn nhà phát triển.")
            }
            AdbSelf.log(msg)
            runOnUiThread {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                if (needManual) openDev()
                refresh()
            }
        }.start()
    }

    private fun shizukuSection(root: LinearLayout) {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "?" }
        root.addView(label("SHIZUKU  ·  v$ver", 12f, ACCENT, true), lp(10))
        root.addView(label(L.tr("Ghép đôi thiết bị"), 22f, INK, true), lp(2))

        // Trang thai
        val s0 = plainCard(root)
        pillShz = newPill()
        rowWithPill(s0, "Shizuku", pillShz, 0)
        subShz = label("", 13f, MUTED).apply { setPadding(0, dp(4), 0, 0) }
        s0.addView(subShz)
        s0.setOnClickListener { checkLink() }

        // Luu y
        val w = plainCard(root)
        w.background = shape(0xFFFDECEA.toInt(), 18, 0xFFF3B9B3.toInt())
        w.addView(label("⚠  " + L.tr("Lưu ý trước khi ghép đôi"), 16f, BAD, true))
        pillWifi = newPill()
        rowWithPill(w, L.tr("Phải kết nối Wi-Fi"), pillWifi, 12)
        note(w, L.tr("Gỡ lỗi không dây chỉ chạy khi điện thoại đang kết nối Wi-Fi (không cần có Internet). Không có Wi-Fi thì không ghép đôi và kết nối được."), INK)
        val pUsb = newPill()
        pill(pUsb, "Không rõ", null)
        rowWithPill(w, L.tr("Để cấp quyền được trên OriginOS"), pUsb, 14)
        note(w, L.tr("Cài đặt → Giới thiệu điện thoại → bấm 7 lần Số bản dựng, rồi bật Gỡ lỗi USB và Gỡ lỗi không dây. OriginOS không cần tài khoản hãng. Nếu lệnh bị chặn, tắt tối ưu pin cho AloGemini và cho phép tự khởi động trong iManager."), INK)
        btn(w, L.tr("Mở Tùy chọn nhà phát triển"), top = 10) { openDev() }

        // Buoc 1
        val s1 = plainCard(root)
        s1.addView(label(L.tr("BƯỚC 1"), 11f, ACCENT, true))
        pillAuto = newPill()
        rowWithPill(s1, L.tr("Tự nhận mã ghép đôi"), pillAuto, 2)
        note(s1, L.tr("Dùng Trợ năng để app tự đọc mã 6 số và cổng trên hộp thoại Ghép nối thiết bị bằng mã ghép đôi, rồi ghép đôi luôn, không cần nhập. Chỉ đọc màn hình của app Cài đặt, không lưu và không gửi mã đi đâu."), MUTED, 13f, 8)
        note(s1, L.tr("Ghép đôi xong, app tự tắt Trợ năng để app ngân hàng không chặn. Các lần sau app tự kết nối lại mà không cần Trợ năng; chỉ bật lại khi phải ghép đôi lần nữa."), 0xFFB26A00.toInt(), 12f, 8)
        btn(s1, L.tr("1. Mở khóa cài đặt bị hạn chế"), top = 12) { openAppSettings() }
        note(s1, L.tr("Thông tin ứng dụng → Quyền → nút 3 gạch → Bỏ hạn chế quyền"), MUTED, 12f, 4)
        btn(s1, L.tr("2. Bật trong cài đặt Trợ năng"), top = 8) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        note(s1, L.tr("Trợ năng → Ứng dụng đã tải xuống → AloGemini – tự nhận mã ghép đôi → bật Sử dụng"), MUTED, 12f, 4)
        btn(s1, L.tr("3. Nếu bật xong tự tắt: bật Tự khởi động"), top = 8) { openAutostart() }
        note(s1, L.tr("Đồng thời vào Pin → AloGemini → chọn Không hạn chế. Có thể bỏ qua cả Bước 1 và nhập mã ở thông báo (Bước 2)."), MUTED, 12f, 4)

        // Buoc 2
        val s2 = plainCard(root)
        s2.addView(label(L.tr("BƯỚC 2"), 11f, ACCENT, true))
        pillNotif = newPill()
        rowWithPill(s2, L.tr("Ghép đôi"), pillNotif, 2)
        note(s2, L.tr("Bật thông báo kết nối rồi mở gỡ lỗi không dây → Ghép nối thiết bị bằng mã ghép nối, sau đó nhập mã 6 số trong thông báo AloGemini. Làm Bước 1 để khỏi phải nhập."), MUTED, 13f, 8)
        btn(s2, L.tr("Bật thông báo kết nối"), top = 12) { enableNotif() }
        btn(s2, L.tr("Mở gỡ lỗi không dây"), top = 8) { AdbSelf.startPairing(this) }
        note(s2, L.tr("Sau khi bấm, một ô nhập mã nổi sẽ hiện trên màn hình Cài đặt (cần quyền Hiển thị trên ứng dụng khác). Gõ mã 6 số vào đó rồi bấm Ghép đôi."), MUTED, 12f, 6)
        btn(s2, L.tr("Cấp quyền Hiển thị trên ứng dụng khác"), top = 8) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
        }
        note(s2, L.tr("Hoặc nhập tay ngay đây (dùng cửa sổ nhỏ / chia đôi màn hình để vừa xem mã vừa gõ):"), MUTED, 12f, 12)
        shzCode = field(s2, L.tr("Mã ghép đôi 6 số"), "123456", "")
        shzPort = field(s2, L.tr("Cổng ghép đôi (số sau dấu : trong hộp thoại)"), "41234", "")
        btn(s2, L.tr("Ghép đôi bằng mã đã nhập"), top = 10) {
            val raw = shzPort.text.toString().trim() + " " + shzCode.text.toString().trim()
            Toast.makeText(this, L.tr("Đang ghép đôi…"), Toast.LENGTH_SHORT).show()
            Thread {
                val r = AdbSelf.pairFromInput(this, raw, 0)
                runOnUiThread { Toast.makeText(this, r, Toast.LENGTH_LONG).show(); refresh() }
            }.start()
        }

        // Cac buoc
        val s3 = plainCard(root)
        s3.addView(label(L.tr("Các bước"), 15f, INK, true))
        note(s3, L.tr("1  Mở khóa cài đặt bị hạn chế, rồi bật Tự nhận mã trong Trợ năng\n2  Bật thông báo kết nối và cho phép thông báo\n3  Mở Gỡ lỗi không dây → Ghép nối thiết bị bằng mã ghép nối; app tự nhận mã\n4  Ứng dụng tự dò cổng và kết nối\n5  Khi làm xong việc cần quyền, bấm Ngắt kết nối & tắt Gỡ lỗi không dây trước khi dùng app ngân hàng"), INK, 13f, 8)

        btnStop = btn(root, L.tr("Dừng ghép đôi"), top = 14) { AdbSelf.stopPairing(this) }
        btn(root, L.tr("Ngắt kết nối & tắt Gỡ lỗi không dây, Tùy chọn nhà phát triển"), top = 8) { disconnectAll() }

        val nt = plainCard(root)
        nt.background = shape(0xFFFFF4E0.toInt(), 18, 0xFFF0D9A8.toInt())
        note(nt, L.tr("Lưu ý: Chưa bật Gỡ lỗi USB (Cài đặt bảo mật) hoặc chưa kết nối thì app không tự tắt được. Khi đó bấm nút Ngắt kết nối, trang Tùy chọn nhà phát triển sẽ mở ra: tắt Gỡ lỗi không dây và Gỡ lỗi USB trước, rồi mới gạt công tắc Tùy chọn nhà phát triển trên cùng."), 0xFF7A5200.toInt(), 13f, 0)

        btn(root, L.tr("Kiểm tra trạng thái ghép đôi"), primary = true, top = 14) { checkLink() }

        val pr = plainCard(root)
        pr.addView(label(L.tr("Tiến trình"), 15f, INK, true))
        progress = TextView(this).apply {
            textSize = 12f; setTextColor(MUTED); typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            background = shape(FIELD, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        pr.addView(progress, lp(8))
    }

    private fun updateShz() {
        if (!::pillShz.isInitialized) return
        when {
            ShizukuHelper.hasPerm() -> {
                pill(pillShz, "Đã kết nối", true)
                subShz.text = L.tr("Đã kết nối qua Shizuku · ") + ShizukuHelper.uidText()
            }
            AdbSelf.linked -> {
                pill(pillShz, "Đã kết nối", true)
                subShz.text = L.tr("Đã kết nối qua ADB tích hợp · chạm để kiểm tra lại")
            }
            else -> {
                pill(pillShz, "Chưa", false)
                subShz.text = L.tr("Chưa kết nối · chạm để kiểm tra lại")
            }
        }
        val wifi = wifiOn()
        pill(pillWifi, if (wifi) "Đã kết nối" else "Chưa kết nối", wifi)
        val auto = AdbSelf.watcherOn(this)
        pill(pillAuto, if (auto) "Đang bật" else "Đang tắt", if (auto) true else null)
        val nOn = try { getSystemService(android.app.NotificationManager::class.java).areNotificationsEnabled() } catch (_: Throwable) { false }
        pill(pillNotif, if (nOn) "Đã bật thông báo" else "Chưa bật thông báo", if (nOn) true else null)
        btnStop.isEnabled = AdbSelf.pairing()
        progress.text = AdbSelf.logText().ifBlank { L.tr("Chưa bắt đầu dò cổng ADB") }
    }

    private fun noShellMsg(): String =
        if (ShizukuHelper.running()) ShizukuHelper.request()
        else L.tr("Chưa có quyền shell. Dùng thẻ “ADB tích hợp” trong mục Kết nối & Quyền hoặc bật Shizuku.")

    private fun grantViaShizuku() {
        if (!Shell.ready()) { Toast.makeText(this, noShellMsg(), Toast.LENGTH_LONG).show(); return }
        Toast.makeText(this, L.tr("Đang cấp quyền…"), Toast.LENGTH_SHORT).show()
        Thread {
            val res = Shell.grantAll(this)
            runOnUiThread { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); refresh(); pushService() }
        }.start()
    }

    private fun runShizukuCmd(cmd: String) {
        if (cmd.isBlank()) return
        if (!Shell.ready()) { shzOut.text = noShellMsg(); return }
        shzOut.text = "$ $cmd\n..."
        Thread {
            val res = try { Shell.exec(cmd) } catch (e: Throwable) { L.tr("Lỗi: ") + e }
            runOnUiThread { shzOut.text = "$ $cmd\n$res" }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        ShizukuHelper.listen { runOnUiThread { refresh() } }
        AdbSelf.onLog = { runOnUiThread { updateShz() } }
        AdbSelf.autoTry(this) { runOnUiThread { refresh() } }
        refresh(); pushService()
    }

    override fun onPause() {
        super.onPause()
        ShizukuHelper.unlisten()
        AdbSelf.onLog = null
        val t = ctsPkg.text.toString().trim()
        if (t.isNotEmpty()) prefs().edit().putString("cts_pkg", t).apply()
        prefs().edit().putString("snd_cls", sndCls.text.toString().trim()).apply()
        val m = miPkgs.text.toString().trim()
        if (m.isNotEmpty()) prefs().edit().putString("mi_pkgs", m).apply()
        pushService()
    }

    private fun refresh() {
        updateShz()
        for ((e, k) in listOf(miInc to "mi_inc", miExc to "mi_exc")) {
            val v = prefs().getString(k, if (k == "mi_inc") MiAiWatcher.DEFAULT_INC else MiAiWatcher.DEFAULT_EXC) ?: ""
            if (e.text.toString().trim() != v) e.setText(v)
        }
        val hasPerm = Restorer.hasPermission(this)
        warnCard.visibility = if (hasPerm) View.GONE else View.VISIBLE

        val r = contentResolver
        val googleOk = Settings.Secure.getString(r, "assistant") == Restorer.GOOGLE_ASSIST &&
            Settings.Secure.getString(r, "voice_interaction_service") == Restorer.GOOGLE_ASSIST
        val pkg = prefs().getString("cts_pkg", "com.parallelc.micts") ?: ""
        val cts = packageManager.getLaunchIntentForPackage(pkg) != null

        stateBox.removeAllViews()
        stateBox.addView(stateRow(hasPerm, L.tr("Quyền ghi cài đặt bảo mật"), L.tr("Đã cấp"), L.tr("Chưa cấp")))
        stateBox.addView(stateRow(ShizukuHelper.hasPerm() || AdbSelf.linked, L.tr("Shizuku (app riêng)"),
            if (ShizukuHelper.hasPerm()) L.tr("Sẵn sàng · ") + ShizukuHelper.uidText() else L.tr("Không cần, đang dùng ADB tích hợp"),
            L.tr(ShizukuHelper.badText())))
        stateBox.addView(stateRow(AdbSelf.linked, L.tr("ADB tích hợp"), L.tr("Đã kết nối"), L.tr("Chưa kết nối")))
        stateBox.addView(stateRow(googleOk, L.tr("Trợ lý mặc định"), "Google", L.tr("Chưa đúng")))
        val joviThere = Restorer.vivoJoviPresent(this)
        stateBox.addView(stateRow(!joviThere || !Restorer.vivoJoviOn(this), L.tr("Jovi trên nút nguồn"),
            if (joviThere) L.tr("Đã tắt") else L.tr("Không có công tắc"), L.tr("Đang bật")))
        stateBox.addView(stateRow(Settings.canDrawOverlays(this), L.tr("Hiển thị trên ứng dụng khác"), L.tr("Đã cấp"), L.tr("Chưa cấp")))
        stateBox.addView(stateRow(Restorer.accessibilityOn(this), L.tr("Trợ năng (theo dõi Jovi)"), L.tr("Đang bật"), L.tr("Đang tắt")))
        stateBox.addView(stateRow(cts, "Circle to Search", L.tr("Đã cài"), L.tr("Chưa cài")))

        status.text = Restorer.status(this) +
            L.tr("\n\nCửa sổ Google vừa thấy (mới nhất trước):\n") +
            (prefs().getString("gseen", "")?.ifBlank { L.tr("(chưa có)") } ?: "") +
            L.tr("\n\nỨng dụng vừa thấy (để tìm tên gói Jovi):\n") +
            (prefs().getString("seen", "")?.ifBlank { L.tr("(chưa có – bật Trợ năng rồi gọi Jovi)") } ?: "")
    }
}
