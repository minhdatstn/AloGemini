package com.gemini.guard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.provider.Settings
import io.github.muntashirakon.adb.AdbPairingRequiredException
import io.github.muntashirakon.adb.android.AdbMdns
import io.github.muntashirakon.adb.android.AndroidUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * ADB tich hop: app tu la ADB client, ket noi vao chinh may qua "Gỡ lỗi không dây" (Android 11+),
 * khong can app Shizuku. Ghep noi 1 lan: tu doc ma bang Tro nang (PairWatcher) hoac nhap ma trong thong bao.
 */
object AdbSelf {
    private const val CH = "adb_pair"
    private const val NID = 7001
    const val KEY_CODE = "code"
    const val EXTRA_PORT = "port"

    @Volatile var linked = false
    @Volatile private var mdns: AdbMdns? = null
    @Volatile private var armedUntil = 0L
    private val trying = AtomicBoolean(false)

    // ---------- Nhat ky "Tien trinh" ----------
    private val logBuf = ArrayDeque<String>()
    @Volatile var onLog: (() -> Unit)? = null

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        synchronized(logBuf) {
            logBuf.addLast("$t  $msg")
            while (logBuf.size > 14) logBuf.removeFirst()
        }
        onLog?.invoke()
    }

    fun logText(): String = synchronized(logBuf) { logBuf.joinToString("\n") }

    // ---------- Trang thai ----------
    fun wirelessOn(c: Context): Boolean =
        try { Settings.Global.getInt(c.contentResolver, "adb_wifi_enabled", 0) == 1 } catch (_: Throwable) { false }

    fun watcherOn(c: Context): Boolean = try {
        val cn = ComponentName(c, PairWatcher::class.java)
        val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        list != null && list.split(':').any { ComponentName.unflattenFromString(it) == cn }
    } catch (_: Throwable) { false }

    /** Dang cho nguoi dung ghep noi (PairWatcher chi hoat dong khi dang "armed"). */
    fun armed(): Boolean = System.currentTimeMillis() < armedUntil

    fun pairing(): Boolean = mdns != null || armed()

    // ---------- Ket noi ----------
    /** Chay tren luong nen. Tra ve thong bao (da dich). */
    fun connect(c: Context): String {
        val r = connectInner(c)
        log(r)
        return r
    }

    private fun connectInner(c: Context): String {
        return try {
            val app = c.applicationContext
            val m = AdbConnectionManager.getInstance(app)
            if (m.isConnected) { linked = true; return L.tr("Đã kết nối ADB") }
            var ok = false
            try {
                ok = m.autoConnect(app, 5000)
            } catch (e: AdbPairingRequiredException) {
                linked = false
                return L.tr("Cần ghép nối trước (làm Bước 1 và Bước 2).")
            } catch (_: Throwable) {
            }
            if (!ok) ok = try { m.connect(5555) } catch (_: Throwable) { false }
            linked = ok
            L.tr(if (ok) "Đã kết nối ADB" else "Không kết nối được. Hãy bật Gỡ lỗi không dây (cùng mạng Wi-Fi).")
        } catch (e: Throwable) {
            linked = false
            L.tr("Lỗi ADB: ") + e.message
        }
    }

    fun disconnect() {
        try { AdbConnectionManager.peek()?.disconnect() } catch (_: Throwable) {}
        linked = false
    }

    /** Tu thu ket noi (neu Go loi khong day dang bat), khong chong lan. */
    fun autoTry(c: Context, done: () -> Unit) {
        if (linked || !wirelessOn(c) || !trying.compareAndSet(false, true)) return
        Thread {
            try { connect(c) } finally { trying.set(false) }
            done()
        }.start()
    }

    // ---------- Ghep noi ----------
    /** Chay tren luong nen. Host/port lay tu hop thoai ghep noi hoac mDNS. */
    fun pair(c: Context, host: String, port: Int, code: String): String {
        val r = try {
            val app = c.applicationContext
            val m = AdbConnectionManager.getInstance(app)
            val ok = m.pair(host, port, code)
            if (!ok) L.tr("Ghép nối thất bại, hãy kiểm tra lại mã.")
            else { armedUntil = 0L; L.tr("Ghép nối xong. ") + connect(app) }
        } catch (e: Throwable) {
            L.tr("Lỗi ghép nối: ") + e.message
        }
        log(r)
        return r
    }

    fun pair(c: Context, port: Int, code: String): String =
        pair(c, AndroidUtils.getHostIpAddress(c.applicationContext), port, code)

    /** Chay lenh shell qua ADB. Chay tren luong nen. */
    fun exec(cmd: String): String {
        val m = AdbConnectionManager.peek() ?: throw IllegalStateException(L.tr("Chưa kết nối ADB"))
        try {
            val st = m.openStream("shell:($cmd) 2>&1; echo \"[exit \$?]\"")
            try {
                return st.openInputStream().bufferedReader().readText().trimEnd()
            } finally {
                try { st.close() } catch (_: Throwable) {}
            }
        } catch (e: Throwable) {
            linked = false
            throw e
        }
    }

    // ---------- Thong bao co o nhap ma ----------
    private fun ensureChannel(app: Context) {
        val nm = app.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(NotificationChannel(CH, "ADB pairing", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun post(app: Context, title: String, text: String, port: Int?) {
        val b = Notification.Builder(app, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOnlyAlertOnce(true).setAutoCancel(port == null)
        if (port != null) {
            val ri = RemoteInput.Builder(KEY_CODE).setLabel(L.tr("Mã ghép nối 6 số")).build()
            val intent = Intent(app, PairReceiver::class.java).putExtra(EXTRA_PORT, port)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pi = PendingIntent.getBroadcast(app, port, intent, flags)
            val act = Notification.Action.Builder(
                Icon.createWithResource(app, android.R.drawable.ic_menu_edit), L.tr("Nhập mã"), pi
            ).addRemoteInput(ri).build()
            b.addAction(act)
        }
        app.getSystemService(NotificationManager::class.java).notify(NID, b.build())
    }

    fun stopMdns() {
        try { mdns?.stop() } catch (_: Throwable) {}
        mdns = null
    }

    fun notifyResult(app: Context, text: String) {
        stopMdns()
        ensureChannel(app)
        post(app, "Gemini Guard · ADB", text, null)
    }

    /** Dung ghep doi: tat do cong, huy thong bao. */
    fun stopPairing(c: Context) {
        stopMdns()
        armedUntil = 0L
        try { c.applicationContext.getSystemService(NotificationManager::class.java).cancel(NID) } catch (_: Throwable) {}
        log(L.tr("Đã dừng ghép đôi."))
    }

    /** Bat dau ghep noi (goi tren luong UI). Mo cai dat de nguoi dung bam "Ghep noi thiet bi bang ma". */
    fun startPairing(c: Context) {
        val app = c.applicationContext
        ensureChannel(app)
        stopMdns()
        armedUntil = System.currentTimeMillis() + 180_000L
        post(app, L.tr("Ghép nối ADB"),
            L.tr("Vào Gỡ lỗi không dây, bấm “Ghép nối thiết bị bằng mã”. Thông báo nhập mã sẽ hiện ra."), null)
        val md = AdbMdns(app, AdbMdns.SERVICE_TYPE_TLS_PAIRING) { _, port ->
            if (port > 0) {
                log(L.fmt("Đã thấy cổng ghép đôi %d.", port))
                post(app, L.tr("Nhập mã ghép nối"),
                    L.tr("Đã thấy cổng ghép nối. Gõ mã 6 số đang hiện trong cài đặt vào ô bên dưới."), port)
            }
        }
        mdns = md
        md.start()
        log(L.tr("Đang chờ hộp thoại ghép đôi (3 phút)…"))
        try {
            c.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            c.startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
