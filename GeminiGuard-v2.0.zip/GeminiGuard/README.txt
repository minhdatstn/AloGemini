ALO GEMINI 5.2 — thuần vivo OriginOS · by Dragon
- Giao diện Obsidian & Gold (Luxury Dark Theme) chia theo 5 mục (Tab).
- Đã thay logo ứng dụng và icon màn hình chính theo ảnh mới, gỡ bỏ hoàn toàn mục Hỗ trợ.
- Tích hợp Thiết lập cử chỉ nút nguồn: tùy chọn Nhấn đúp nút nguồn hoặc Nhấn giữ nút nguồn để mở nhanh Gemini hoặc Circle to Search.
- Repo GitHub chỉ để 1 file zip tên GeminiGuard-v2.0.zip (xóa zip cũ rồi upload file này). Actions tự build APK.
- Cài APK ĐÈ LÊN bản cũ (không gỡ app) để giữ quyền ADB.
