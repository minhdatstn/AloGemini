package com.gemini.guard

import android.app.Application
import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.PRNGFixes
import org.lsposed.hiddenapibypass.HiddenApiBypass

/** Nap ngon ngu giao dien cho moi thanh phan (Activity, dich vu, receiver). */
class GuardApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // ADB tich hop dung Conscrypt cua he thong (TLS 1.3) nen can mo hidden API.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
        }
    }

    override fun onCreate() {
        super.onCreate()
        try { PRNGFixes.apply() } catch (_: Throwable) {}
        L.load(this)
    }
}
