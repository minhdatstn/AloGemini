package com.gemini.guard

import android.content.Context

/** Bat/tat rieng dich vu Tro nang cua Gemini Guard bang tay (dung chung cho o Control Center va phim tat app). */
object AccToggle {
    /** Dao trang thai. Khi tat bang tay se danh dau acc_tile_off de Restorer / canh nen khong tu bat lai. */
    fun toggle(c: Context): String {
        if (!Restorer.hasPermission(c)) return L.tr("Chưa cấp quyền WRITE_SECURE_SETTINGS (cấp bằng ADB trước).")
        val pr = Restorer.prefs(c)
        return if (BankGuard.isAccessibilityOn(c)) {
            pr.edit().putBoolean("acc_tile_off", true).apply()
            if (BankGuard.setAccessibility(c, false)) {
                L.tr("Đã tắt Trợ năng Gemini Guard")
            } else {
                pr.edit().putBoolean("acc_tile_off", false).apply()
                L.tr("Không tắt được Trợ năng")
            }
        } else {
            pr.edit().putBoolean("acc_tile_off", false).putBoolean("bank_disabled_by_us", false).apply()
            if (BankGuard.setAccessibility(c, true)) L.tr("Đã bật Trợ năng Gemini Guard") else L.tr("Không bật được Trợ năng")
        }
    }
}
