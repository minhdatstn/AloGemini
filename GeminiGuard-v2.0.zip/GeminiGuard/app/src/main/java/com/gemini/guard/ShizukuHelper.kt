package com.gemini.guard

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Chay lenh shell voi quyen ADB (hoac root) thong qua Shizuku, ngay tren may. */
object ShizukuHelper {
    private const val REQ = 4242
    @Volatile private var onChange: (() -> Unit)? = null

    private val bin = Shizuku.OnBinderReceivedListener { onChange?.invoke() }
    private val dead = Shizuku.OnBinderDeadListener { onChange?.invoke() }
    private val perm = Shizuku.OnRequestPermissionResultListener { _, _ -> onChange?.invoke() }

    fun listen(cb: () -> Unit) {
        unlisten()
        onChange = cb
        Shizuku.addBinderReceivedListener(bin)
        Shizuku.addBinderDeadListener(dead)
        Shizuku.addRequestPermissionResultListener(perm)
    }

    fun unlisten() {
        onChange = null
        Shizuku.removeBinderReceivedListener(bin)
        Shizuku.removeBinderDeadListener(dead)
        Shizuku.removeRequestPermissionResultListener(perm)
    }

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun hasPerm(): Boolean = try {
        running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    /** Chuoi mo ta khi chua san sang (tieng Viet, goi L.tr khi hien thi). */
    fun badText(): String = if (!running()) "Chưa chạy" else "Chưa cấp quyền cho app"

    /** Xin quyen Shizuku. Tra ve thong bao (da dich) de hien cho nguoi dung. */
    fun request(): String = try {
        when {
            !running() -> L.tr("Shizuku chưa chạy. Mở app Shizuku và khởi động nó trước.")
            Shizuku.isPreV11() -> L.tr("Shizuku quá cũ, hãy cập nhật app Shizuku.")
            hasPerm() -> L.tr("Đã có quyền Shizuku")
            Shizuku.shouldShowRequestPermissionRationale() ->
                L.tr("Bạn đã từ chối. Hãy cấp quyền cho Gemini Guard trong app Shizuku.")
            else -> { Shizuku.requestPermission(REQ); L.tr("Đang xin quyền Shizuku…") }
        }
    } catch (e: Throwable) { L.tr("Lỗi Shizuku: ") + e.message }

    fun uidText(): String = try {
        val u = Shizuku.getUid(); "uid $u (" + (if (u == 0) "root" else "adb") + ")"
    } catch (_: Throwable) { "?" }

    /** Shizuku.newProcess la private tu API 13 nen goi bang reflection. Chay tren luong nen. */
    fun exec(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText().trimEnd()
        val code = p.waitFor()
        return "$out\n[exit $code]"
    }

    /** Tu cap cac quyen ma truoc day phai go lenh adb tren may tinh. Chay tren luong nen. */
    fun grantAll(c: Context): String {
        val pkg = c.packageName
        val sb = StringBuilder()
        try {
            val r1 = exec("pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
            if (!Restorer.hasPermission(c)) sb.append(L.tr("Không cấp được WRITE_SECURE_SETTINGS: ")).append(r1)
            else sb.append(L.tr("Đã cấp WRITE_SECURE_SETTINGS"))
            exec("appops set $pkg GET_USAGE_STATS allow")
            exec("appops set $pkg SYSTEM_ALERT_WINDOW allow")
            sb.append(L.tr(" · đã thử cấp Truy cập sử dụng và Hiển thị trên ứng dụng khác"))
        } catch (e: Throwable) {
            sb.append(L.tr("Lỗi Shizuku: ")).append(e.message)
        }
        return sb.toString()
    }
}
