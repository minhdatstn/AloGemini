package com.gemini.guard

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import org.lsposed.hiddenapibypass.HiddenApiBypass
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast

class BarOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private var view: View? = null

    fun refresh() {
        val on = Restorer.prefs(ctx).getBoolean("bar", false)
        if (on && Settings.canDrawOverlays(ctx)) show() else hide()
    }

    private fun show() {
        hide()
        val p = Restorer.prefs(ctx)
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels * p.getInt("bar_w", 40) / 100
        val h = (dm.density * p.getInt("bar_h", 20)).toInt().coerceAtLeast(8)
        val y = (dm.density * p.getInt("bar_y", 0)).toInt()
        val alpha = p.getInt("bar_a", 30) * 255 / 100

        val v = View(ctx)
        v.background = GradientDrawable().apply {
            cornerRadius = h / 2f
            setColor(Color.argb(alpha, 255, 255, 255))
        }
        val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) {
                val a = currentAction(Restorer.prefs(ctx), "bar_lp")
                if (a == "none") return
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                performAction(a)
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val a = currentAction(Restorer.prefs(ctx), "bar_dt")
                if (a != "none") {
                    v.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    performAction(a)
                }
                return true
            }
        })
        v.setOnTouchListener { _, e -> gd.onTouchEvent(e) }

        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            this.y = y
        }
        try { wm.addView(v, lp); view = v } catch (e: Exception) {
            Toast.makeText(ctx, L.tr("Không hiện được thanh: ") + e.message, Toast.LENGTH_LONG).show()
        }
    }

    fun hide() {
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }

    /** Dam bao assistant/voice_interaction_service dang la Google truoc khi goi. Tra ve true neu vua phai sua. */
    private fun preflight(): Boolean {
        if (!Restorer.hasPermission(ctx)) {
            Toast.makeText(ctx,
                L.tr("Chưa cấp WRITE_SECURE_SETTINGS → trợ lý có thể bị sai (hiện bảng chọn). Mở Gemini Guard để lấy lệnh ADB."),
                Toast.LENGTH_LONG).show()
            return false
        }
        return Restorer.ensure(ctx).isNotEmpty()
    }

    /** Thuc hien hanh dong da chon cho cu chi. */
    private fun performAction(action: String) {
        when (action) {
            "gemini" -> launchAssist()
            "micts" -> launchCts()
        }
    }

    private fun launchCts() {
        if (preflight()) {
            // Cho he thong ap dung cai dat roi moi mo Circle to Search
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ doLaunchCts() }, 400)
        } else doLaunchCts()
    }

    private fun doLaunchCts() {
        val pkg = Restorer.prefs(ctx).getString("cts_pkg", "com.parallelc.micts") ?: "com.parallelc.micts"
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            Toast.makeText(ctx, L.fmt("Chưa cài Circle to Search (%s)", pkg), Toast.LENGTH_LONG).show(); return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {
            Toast.makeText(ctx, L.tr("Lỗi mở Circle to Search: ") + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private fun launchAssist() {
        preflight()
        val err = Restorer.callTarget(ctx)
        if (err == null) GeminiSound.play(ctx)
        else Toast.makeText(ctx, L.fmt("Không gọi được %s: %s", Restorer.targetLabel(ctx), err), Toast.LENGTH_LONG).show()
    }

    companion object {
        /** (gia tri, nhan hien thi) */
        val ACTIONS = listOf(
            "gemini" to "Gọi Gemini",
            "micts" to "Circle to Search",
            "none" to "Không làm gì"
        )

        /** Hanh dong cua cu chi `bar_dt` (cham dup) / `bar_lp` (giu). */
        fun currentAction(pr: SharedPreferences, key: String): String {
            pr.getString(key, null)?.let { v -> if (ACTIONS.any { it.first == v }) return v }
            return if (key == "bar_dt") "gemini" else "micts"
        }
    }
}
