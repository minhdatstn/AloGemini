package com.gemini.guard

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Hop thoai nhap ma ghep doi, mo khi cham vao thong bao. La Activity dang dialog (trong suot, o task rieng)
 * nen app Cai dat ben duoi chi bi tam dung chu khong bi dung, hop thoai ghep noi van con.
 */
class PairInputActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(12))
        }
        box.addView(TextView(this).apply {
            text = L.tr("Nhập mã ghép đôi"); textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = L.tr("Gõ mã 6 số đang hiện trong hộp thoại. Nếu báo thiếu cổng, gõ cổng trước mã, ví dụ: 41234 123456")
            textSize = 13f
        })
        val et = EditText(this).apply {
            hint = L.tr("Mã 6 số (thêm cổng nếu cần)")
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            requestFocus()
        }
        box.addView(et)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val ok = Button(this).apply { text = L.tr("Ghép đôi"); isAllCaps = false }
        val cancel = Button(this).apply { text = L.tr("Đóng"); isAllCaps = false }
        row.addView(ok, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(row)
        setContentView(box)

        ok.setOnClickListener {
            val raw = et.text.toString()
            val app = applicationContext
            Toast.makeText(app, L.tr("Đang ghép đôi…"), Toast.LENGTH_SHORT).show()
            Thread {
                val r = AdbSelf.pairFromInput(app, raw, AdbSelf.lastPort)
                AdbSelf.notifyResult(app, r)
                runOnUiThread { Toast.makeText(app, r, Toast.LENGTH_LONG).show() }
            }.start()
            finish()
        }
        cancel.setOnClickListener { finish() }
    }
}
